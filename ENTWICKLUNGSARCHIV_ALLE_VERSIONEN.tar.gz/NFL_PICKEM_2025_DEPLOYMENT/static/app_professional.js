// NFL PickEm 2025 - Professional App JavaScript
let currentUser = null;
let currentWeek = 2;
let currentSection = 'dashboard';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    console.log('NFL PickEm App initializing...');
    
    // Check for existing user session
    const savedUser = localStorage.getItem('nfl_pickem_user');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            updateAuthUI();
            console.log('User session restored:', currentUser.username);
        } catch (e) {
            console.error('Error parsing saved user:', e);
            localStorage.removeItem('nfl_pickem_user');
        }
    }
    
    // Initialize UI components
    initializeNavigation();
    initializeAuth();
    initializeCountdown();
    loadCurrentWeek();
    showSection('dashboard');
    
    console.log('NFL PickEm App initialized successfully');
});

// Navigation Management
function initializeNavigation() {
    const burgerMenu = document.getElementById('burger-menu');
    const sideNav = document.getElementById('side-nav');
    const navOverlay = document.getElementById('nav-overlay');
    const navClose = document.getElementById('nav-close');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Burger menu toggle
    if (burgerMenu) {
        burgerMenu.addEventListener('click', function() {
            toggleNavigation();
        });
    }
    
    // Navigation close
    if (navClose) {
        navClose.addEventListener('click', function() {
            closeNavigation();
        });
    }
    
    // Overlay click to close
    if (navOverlay) {
        navOverlay.addEventListener('click', function() {
            closeNavigation();
        });
    }
    
    // Navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.dataset.section;
            if (section) {
                showSection(section);
                setActiveNavLink(this);
                closeNavigation();
            }
        });
    });
    
    // Escape key to close navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeNavigation();
            closeUserDropdown();
            closeModal();
        }
    });
}

function toggleNavigation() {
    const sideNav = document.getElementById('side-nav');
    const navOverlay = document.getElementById('nav-overlay');
    const burgerMenu = document.getElementById('burger-menu');
    
    if (sideNav && navOverlay && burgerMenu) {
        const isOpen = sideNav.classList.contains('open');
        
        if (isOpen) {
            closeNavigation();
        } else {
            openNavigation();
        }
    }
}

function openNavigation() {
    const sideNav = document.getElementById('side-nav');
    const navOverlay = document.getElementById('nav-overlay');
    const burgerMenu = document.getElementById('burger-menu');
    
    if (sideNav && navOverlay && burgerMenu) {
        sideNav.classList.add('open');
        navOverlay.classList.add('show');
        burgerMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeNavigation() {
    const sideNav = document.getElementById('side-nav');
    const navOverlay = document.getElementById('nav-overlay');
    const burgerMenu = document.getElementById('burger-menu');
    
    if (sideNav && navOverlay && burgerMenu) {
        sideNav.classList.remove('open');
        navOverlay.classList.remove('show');
        burgerMenu.classList.remove('active');
        document.body.style.overflow = '';
    }
}

function setActiveNavLink(activeLink) {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}

// Authentication Management
function initializeAuth() {
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const userAvatar = document.getElementById('user-avatar');
    const userDropdown = document.getElementById('user-dropdown');
    const loginForm = document.getElementById('login-form');
    const modalClose = document.getElementById('modal-close');
    
    // Login button
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            showLoginModal();
        });
    }
    
    // Logout button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            logout();
            closeUserDropdown();
        });
    }
    
    // User avatar dropdown
    if (userAvatar) {
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleUserDropdown();
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function() {
        closeUserDropdown();
    });
    
    // Prevent dropdown close when clicking inside
    if (userDropdown) {
        userDropdown.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
    
    // Login form
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Modal close
    if (modalClose) {
        modalClose.addEventListener('click', function() {
            closeModal();
        });
    }
    
    // Modal overlay close
    const modal = document.getElementById('login-modal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    }
    
    // Update auth UI
    updateAuthUI();
}

function toggleUserDropdown() {
    const userDropdown = document.getElementById('user-dropdown');
    if (userDropdown) {
        userDropdown.classList.toggle('show');
    }
}

function closeUserDropdown() {
    const userDropdown = document.getElementById('user-dropdown');
    if (userDropdown) {
        userDropdown.classList.remove('show');
    }
}

function showLoginModal() {
    const modal = document.getElementById('login-modal');
    if (modal) {
        modal.style.display = 'block';
        modal.setAttribute('aria-hidden', 'false');
        
        // Focus first input
        const firstInput = modal.querySelector('input');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    const modal = document.getElementById('login-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        
        // Clear form
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

async function handleLogin() {
    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    const submitBtn = document.querySelector('.login-submit-btn');
    
    if (!usernameInput || !passwordInput) {
        showToast('Login-Formular nicht gefunden', 'error');
        return;
    }
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    
    if (!username || !password) {
        showToast('Bitte Benutzername und Passwort eingeben', 'warning');
        return;
    }
    
    // Show loading state
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Anmelden...';
    }
    
    try {
        console.log('Attempting login for:', username);
        
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        console.log('Login response status:', response.status);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Login fehlgeschlagen' }));
            throw new Error(errorData.message || 'Login fehlgeschlagen');
        }
        
        const data = await response.json();
        console.log('Login successful:', data);
        
        if (data.user) {
            currentUser = data.user;
            localStorage.setItem('nfl_pickem_user', JSON.stringify(currentUser));
            
            // Close modal
            closeModal();
            
            // Update UI
            updateAuthUI();
            
            // Reload current section
            loadSectionData(currentSection);
            
            showToast(`Willkommen zurück, ${currentUser.username}!`, 'success');
        } else {
            throw new Error('Keine Benutzerdaten erhalten');
        }
        
    } catch (error) {
        console.error('Login error:', error);
        showToast(error.message || 'Login fehlgeschlagen', 'error');
    } finally {
        // Reset button state
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Anmelden';
        }
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('nfl_pickem_user');
    updateAuthUI();
    showSection('dashboard');
    showToast('Erfolgreich abgemeldet', 'info');
}

function updateAuthUI() {
    const loginBtn = document.getElementById('login-btn');
    const userMenu = document.getElementById('user-menu');
    const headerUsername = document.getElementById('header-username');
    const dropdownUsername = document.getElementById('dropdown-username');
    const navStats = document.getElementById('nav-stats');
    
    if (currentUser) {
        // User is logged in
        if (loginBtn) loginBtn.style.display = 'none';
        if (userMenu) userMenu.style.display = 'block';
        if (headerUsername) headerUsername.textContent = currentUser.username;
        if (dropdownUsername) dropdownUsername.textContent = currentUser.username;
        if (navStats) navStats.style.display = 'block';
        
        // Load user stats for navigation
        loadUserStatsForNav();
    } else {
        // User is not logged in
        if (loginBtn) loginBtn.style.display = 'flex';
        if (userMenu) userMenu.style.display = 'none';
        if (headerUsername) headerUsername.textContent = 'Gast';
        if (dropdownUsername) dropdownUsername.textContent = 'Gast';
        if (navStats) navStats.style.display = 'none';
    }
}

// Countdown Management
function initializeCountdown() {
    updateCountdown();
    setInterval(updateCountdown, 1000);
}

function updateCountdown() {
    // Calculate time until next Sunday 19:00 Vienna time
    const now = new Date();
    const nextSunday = new Date();
    
    // Find next Sunday
    const daysUntilSunday = (7 - now.getDay()) % 7;
    if (daysUntilSunday === 0 && now.getHours() >= 19) {
        // If it's Sunday after 19:00, go to next Sunday
        nextSunday.setDate(now.getDate() + 7);
    } else {
        nextSunday.setDate(now.getDate() + daysUntilSunday);
    }
    
    nextSunday.setHours(19, 0, 0, 0);
    
    const timeDiff = nextSunday.getTime() - now.getTime();
    
    if (timeDiff > 0) {
        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        
        const countdownDays = document.getElementById('countdown-days');
        const countdownHours = document.getElementById('countdown-hours');
        const countdownMinutes = document.getElementById('countdown-minutes');
        
        if (countdownDays) countdownDays.textContent = String(days).padStart(2, '0');
        if (countdownHours) countdownHours.textContent = String(hours).padStart(2, '0');
        if (countdownMinutes) countdownMinutes.textContent = String(minutes).padStart(2, '0');
    }
}

// Section Management
function showSection(sectionName) {
    console.log('Showing section:', sectionName);
    currentSection = sectionName;
    
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionName + '-section');
    if (targetSection) {
        targetSection.classList.add('active');
        
        // Load section data
        loadSectionData(sectionName);
        
        // Update page title
        updatePageTitle(sectionName);
    }
}

function updatePageTitle(sectionName) {
    const titles = {
        'dashboard': 'Dashboard',
        'picks': 'Meine Picks',
        'leaderboard': 'Rangliste',
        'all-picks': 'Alle Picks',
        'rules': 'Spielregeln'
    };
    
    const title = titles[sectionName] || 'NFL PickEm';
    document.title = `${title} - NFL PickEm`;
}

function loadSectionData(sectionName) {
    switch (sectionName) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'picks':
            loadPicksData();
            break;
        case 'leaderboard':
            loadLeaderboardData();
            break;
        case 'all-picks':
            loadAllPicksData();
            break;
        case 'rules':
            // Rules are static, no loading needed
            break;
    }
}

// Data Loading Functions
async function loadCurrentWeek() {
    try {
        const response = await fetch('/api/current-week');
        if (response.ok) {
            const data = await response.json();
            currentWeek = data.current_week;
            
            const navCurrentWeek = document.getElementById('nav-current-week');
            if (navCurrentWeek) {
                navCurrentWeek.textContent = currentWeek;
            }
            
            // Update week selector
            const weekSelect = document.getElementById('week-select');
            if (weekSelect) {
                weekSelect.value = currentWeek;
            }
            
            console.log('Current week:', currentWeek);
        }
    } catch (error) {
        console.error('Error loading current week:', error);
    }
}

async function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    if (!currentUser) {
        showDefaultDashboard();
        return;
    }
    
    try {
        // Load all dashboard data in parallel
        await Promise.all([
            loadUserStats(),
            loadOpponentScores(),
            loadRecentPicks(),
            loadEliminatedTeams()
        ]);
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

function showDefaultDashboard() {
    const userScore = document.getElementById('user-score');
    const userRank = document.getElementById('user-rank');
    const opponentScores = document.getElementById('opponent-scores');
    const recentPicks = document.getElementById('recent-picks');
    const eliminatedTeams = document.getElementById('eliminated-teams');
    
    if (userScore) userScore.textContent = '-';
    if (userRank) userRank.textContent = 'Rang: -';
    if (opponentScores) opponentScores.innerHTML = '<div class="empty-state"><i class="fas fa-users"></i><p>Bitte einloggen um Punkte zu sehen</p></div>';
    if (recentPicks) recentPicks.innerHTML = '<div class="empty-state"><i class="fas fa-history"></i><p>Bitte einloggen um Picks zu sehen</p></div>';
    if (eliminatedTeams) eliminatedTeams.innerHTML = '<div class="empty-state"><i class="fas fa-ban"></i><p>Bitte einloggen um eliminierte Teams zu sehen</p></div>';
}

async function loadUserStats() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/user-stats?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            
            const userScore = document.getElementById('user-score');
            const userRank = document.getElementById('user-rank');
            
            if (userScore) userScore.textContent = data.total_points || 0;
            if (userRank) userRank.textContent = `Rang: ${data.rank || '-'}`;
        }
    } catch (error) {
        console.error('Error loading user stats:', error);
    }
}

async function loadUserStatsForNav() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/user-stats?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            
            const navUserScore = document.getElementById('nav-user-score');
            const navUserRank = document.getElementById('nav-user-rank');
            
            if (navUserScore) navUserScore.textContent = data.total_points || 0;
            if (navUserRank) navUserRank.textContent = data.rank || '-';
        }
        
        // Load eliminated count
        const eliminatedResponse = await fetch(`/api/picks/eliminated?user_id=${currentUser.id}`);
        if (eliminatedResponse.ok) {
            const eliminatedData = await eliminatedResponse.json();
            const navEliminatedCount = document.getElementById('nav-eliminated-count');
            if (navEliminatedCount) {
                navEliminatedCount.textContent = eliminatedData.eliminated_teams?.length || 0;
            }
        }
        
    } catch (error) {
        console.error('Error loading user stats for nav:', error);
    }
}

async function loadOpponentScores() {
    try {
        const response = await fetch('/api/leaderboard');
        if (response.ok) {
            const data = await response.json();
            const opponentScores = document.getElementById('opponent-scores');
            
            if (opponentScores && data.leaderboard) {
                let html = '';
                data.leaderboard.forEach(user => {
                    if (!currentUser || user.username !== currentUser.username) {
                        html += `
                            <div class="opponent-score">
                                <span class="opponent-name">${user.username}</span>
                                <span class="opponent-points">${user.total_points}</span>
                            </div>
                        `;
                    }
                });
                opponentScores.innerHTML = html || '<div class="empty-state"><i class="fas fa-users"></i><p>Keine anderen Spieler</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading opponent scores:', error);
    }
}

async function loadRecentPicks() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/picks/recent?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const recentPicks = document.getElementById('recent-picks');
            
            if (recentPicks) {
                if (data.picks && data.picks.length > 0) {
                    let html = '';
                    data.picks.slice(0, 3).forEach(pick => {
                        const result = pick.points > 0 ? '✅' : (pick.points === 0 ? '❌' : '⏳');
                        html += `
                            <div class="recent-pick">
                                <strong>Woche ${pick.week}:</strong> ${pick.team_name} ${result}
                            </div>
                        `;
                    });
                    recentPicks.innerHTML = html;
                } else {
                    recentPicks.innerHTML = '<div class="empty-state"><i class="fas fa-history"></i><p>Noch keine Picks gemacht</p></div>';
                }
            }
        }
    } catch (error) {
        console.error('Error loading recent picks:', error);
    }
}

async function loadEliminatedTeams() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/picks/eliminated?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const eliminatedTeams = document.getElementById('eliminated-teams');
            
            if (eliminatedTeams) {
                if (data.eliminated_teams && data.eliminated_teams.length > 0) {
                    let html = '';
                    // Remove duplicates
                    const uniqueTeams = data.eliminated_teams.filter((team, index, self) => 
                        index === self.findIndex(t => t.abbreviation === team.abbreviation)
                    );
                    
                    uniqueTeams.forEach(team => {
                        html += `
                            <div class="eliminated-team">
                                <img src="${team.logo_url}" alt="${team.name}" class="eliminated-team-logo">
                                <span>${team.name}</span>
                            </div>
                        `;
                    });
                    eliminatedTeams.innerHTML = html;
                } else {
                    eliminatedTeams.innerHTML = '<div class="empty-state"><i class="fas fa-ban"></i><p>Keine Teams eliminiert</p></div>';
                }
            }
        }
    } catch (error) {
        console.error('Error loading eliminated teams:', error);
    }
}

async function loadPicksData() {
    console.log('Loading picks data...');
    
    const weekSelect = document.getElementById('week-select');
    const selectedWeek = weekSelect ? parseInt(weekSelect.value) : currentWeek;
    
    // Setup week selector
    if (weekSelect) {
        weekSelect.addEventListener('change', function() {
            const selectedWeek = parseInt(this.value);
            loadMatchesForWeek(selectedWeek);
        });
    }
    
    await loadMatchesForWeek(selectedWeek);
}

async function loadMatchesForWeek(week) {
    console.log('Loading matches for week:', week);
    
    try {
        const matchesContainer = document.getElementById('matches-container');
        if (!matchesContainer) return;
        
        matchesContainer.innerHTML = '<div class="loading-matches"><i class="fas fa-spinner fa-spin"></i>Lade Spiele...</div>';
        
        const response = await fetch(`/api/matches?week=${week}`);
        if (!response.ok) {
            throw new Error('Failed to load matches');
        }
        
        const data = await response.json();
        
        if (!data.matches || data.matches.length === 0) {
            matchesContainer.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><p>Keine Spiele für diese Woche gefunden</p></div>';
            return;
        }
        
        // Get team usage data if user is logged in
        let teamUsage = {};
        if (currentUser) {
            try {
                const usageResponse = await fetch(`/api/picks/team-usage?user_id=${currentUser.id}`);
                if (usageResponse.ok) {
                    const usageData = await usageResponse.json();
                    usageData.team_usage.forEach(usage => {
                        teamUsage[usage.team.abbreviation] = usage.status;
                    });
                }
            } catch (error) {
                console.error('Error loading team usage:', error);
            }
        }
        
        // Render matches
        let html = '';
        data.matches.forEach(match => {
            html += renderMatchCard(match, teamUsage);
        });
        
        matchesContainer.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading matches:', error);
        const matchesContainer = document.getElementById('matches-container');
        if (matchesContainer) {
            matchesContainer.innerHTML = '<div class="error-state"><i class="fas fa-exclamation-triangle"></i><p>Fehler beim Laden der Spiele</p></div>';
        }
    }
}

function renderMatchCard(match, teamUsage = {}) {
    const gameStarted = new Date(match.game_time) <= new Date();
    const homeTeamStatus = teamUsage[match.home_team.abbreviation] || 'available';
    const awayTeamStatus = teamUsage[match.away_team.abbreviation] || 'available';
    
    const homeTeamUnavailable = homeTeamStatus === 'eliminated' || homeTeamStatus === 'max_used';
    const awayTeamUnavailable = awayTeamStatus === 'eliminated' || awayTeamStatus === 'max_used';
    
    return `
        <div class="match-card ${gameStarted ? 'game-started' : ''}">
            <div class="match-header">
                <span><i class="fas fa-clock"></i> ${new Date(match.game_time).toLocaleString('de-DE')}</span>
                ${gameStarted ? '<span class="game-started-info"><i class="fas fa-play"></i> Spiel läuft</span>' : ''}
            </div>
            <div class="match-button ${gameStarted ? 'disabled' : ''}" 
                 onclick="${gameStarted ? '' : `openPickModal(${match.id})`}">
                <div class="match-teams-display">
                    <div class="team-display ${awayTeamUnavailable ? 'team-unavailable' : ''}" 
                         data-team="${match.away_team.abbreviation}">
                        <img src="${match.away_team.logo_url}" alt="${match.away_team.name}" class="team-logo-large">
                        <div class="team-name">${match.away_team.name}</div>
                        ${awayTeamUnavailable ? '<div class="unavailable-reason">Nicht verfügbar</div>' : ''}
                    </div>
                    <div class="match-vs">@</div>
                    <div class="team-display ${homeTeamUnavailable ? 'team-unavailable' : ''}" 
                         data-team="${match.home_team.abbreviation}">
                        <img src="${match.home_team.logo_url}" alt="${match.home_team.name}" class="team-logo-large">
                        <div class="team-name">${match.home_team.name}</div>
                        ${homeTeamUnavailable ? '<div class="unavailable-reason">Nicht verfügbar</div>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function openPickModal(matchId) {
    if (!currentUser) {
        showToast('Bitte zuerst einloggen', 'warning');
        return;
    }
    
    console.log('Opening pick modal for match:', matchId);
    showToast('Pick-Funktionalität wird implementiert', 'info');
}

async function loadLeaderboardData() {
    console.log('Loading leaderboard data...');
    
    try {
        const container = document.getElementById('leaderboard-container');
        if (!container) return;
        
        container.innerHTML = '<div class="loading-leaderboard"><i class="fas fa-spinner fa-spin"></i>Lade Rangliste...</div>';
        
        const response = await fetch('/api/leaderboard');
        if (response.ok) {
            const data = await response.json();
            
            if (data.leaderboard && data.leaderboard.length > 0) {
                let html = '<div class="leaderboard-table">';
                data.leaderboard.forEach((user, index) => {
                    const isCurrentUser = currentUser && user.username === currentUser.username;
                    html += `
                        <div class="leaderboard-row ${isCurrentUser ? 'current-user' : ''}">
                            <span class="rank">${index + 1}</span>
                            <span class="username">
                                ${isCurrentUser ? '<i class="fas fa-user"></i> ' : ''}
                                ${user.username}
                            </span>
                            <span class="points">${user.total_points}</span>
                        </div>
                    `;
                });
                html += '</div>';
                container.innerHTML = html;
            } else {
                container.innerHTML = '<div class="empty-state"><i class="fas fa-trophy"></i><p>Noch keine Rangliste verfügbar</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
        const container = document.getElementById('leaderboard-container');
        if (container) {
            container.innerHTML = '<div class="error-state"><i class="fas fa-exclamation-triangle"></i><p>Fehler beim Laden der Rangliste</p></div>';
        }
    }
}

async function loadAllPicksData() {
    console.log('Loading all picks data...');
    
    try {
        const container = document.getElementById('all-picks-container');
        if (!container) return;
        
        container.innerHTML = '<div class="loading-picks"><i class="fas fa-spinner fa-spin"></i>Lade alle Picks...</div>';
        
        const response = await fetch('/api/picks/all');
        if (response.ok) {
            const data = await response.json();
            
            if (data.picks && data.picks.length > 0) {
                // Group picks by week
                const picksByWeek = {};
                data.picks.forEach(pick => {
                    if (!picksByWeek[pick.week]) {
                        picksByWeek[pick.week] = [];
                    }
                    picksByWeek[pick.week].push(pick);
                });
                
                let html = '';
                Object.keys(picksByWeek).sort((a, b) => b - a).forEach(week => {
                    html += `
                        <div class="week-picks">
                            <h3><i class="fas fa-calendar-week"></i> Woche ${week}</h3>
                            <div class="picks-grid">
                    `;
                    
                    picksByWeek[week].forEach(pick => {
                        const result = pick.points > 0 ? 'win' : (pick.points === 0 ? 'loss' : 'pending');
                        const resultIcon = pick.points > 0 ? 'check-circle' : (pick.points === 0 ? 'times-circle' : 'clock');
                        
                        html += `
                            <div class="pick-item ${result}">
                                <div class="pick-user">${pick.username}</div>
                                <div class="pick-team">${pick.team_name}</div>
                                <div class="pick-result">
                                    <i class="fas fa-${resultIcon}"></i>
                                    ${pick.points || 0}
                                </div>
                            </div>
                        `;
                    });
                    
                    html += '</div></div>';
                });
                
                container.innerHTML = html;
            } else {
                container.innerHTML = '<div class="empty-state"><i class="fas fa-list"></i><p>Noch keine Picks verfügbar</p></div>';
            }
        }
    } catch (error) {
        console.error('Error loading all picks:', error);
        const container = document.getElementById('all-picks-container');
        if (container) {
            container.innerHTML = '<div class="error-state"><i class="fas fa-exclamation-triangle"></i><p>Fehler beim Laden der Picks</p></div>';
        }
    }
}

// Toast Notification System
function showToast(message, type = 'info', duration = 4000) {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    
    toast.innerHTML = `
        <i class="fas fa-${icons[type] || 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    toastContainer.appendChild(toast);
    
    // Show toast
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Hide and remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, duration);
}

// Global functions for onclick handlers
window.openPickModal = openPickModal;
window.showSection = showSection;

// Service Worker Registration (for PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Service worker registration would go here for PWA
        console.log('NFL PickEm App ready for PWA enhancement');
    });
}

