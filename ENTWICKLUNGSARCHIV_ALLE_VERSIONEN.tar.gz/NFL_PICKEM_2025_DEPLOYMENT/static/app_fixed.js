// NFL PickEm 2025 - Fixed Frontend JavaScript
const API_BASE = '';

// Global variables
let currentUser = null;
let currentWeek = null;

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing app...');
    
    const urlParams = new URLSearchParams(window.location.search);
    const section = urlParams.get('section');
    const week = urlParams.get('week');

    initializeApp(section, week);
});

// Initialize the app
async function initializeApp(section = null, week = null) {
    console.log('Initializing app...');
    
    setupNavigation();
    setupModal();
    setupLoginForm();
    
    // Initialize pick modal
    initializePickModal();
    
    await checkAuthStatus();
    await getCurrentWeek();

    if (section) {
        showSection(section);
        if (section === 'picks' && week) {
            currentWeek = parseInt(week) || currentWeek;
            loadPicksData(week);
        }
    } else {
        showSection('dashboard');
    }
}

// Set up navigation
function setupNavigation() {
    console.log('Setting up navigation...');
    
    const dashboardLink = document.getElementById('dashboard-link');
    const picksLink = document.getElementById('picks-link');
    const leaderboardLink = document.getElementById('leaderboard-link');
    const allPicksLink = document.getElementById('all-picks-link');
    
    if (dashboardLink) {
        dashboardLink.addEventListener('click', function(e) {
            e.preventDefault();
            updateURL('dashboard');
            showSection('dashboard');
        });
    }
    
    if (picksLink) {
        picksLink.addEventListener('click', function(e) {
            e.preventDefault();
            updateURL('picks', currentWeek);
            showSection('picks');
        });
    }
    
    if (leaderboardLink) {
        leaderboardLink.addEventListener('click', function(e) {
            e.preventDefault();
            updateURL('leaderboard');
            showSection('leaderboard');
        });
    }
    
    if (allPicksLink) {
        allPicksLink.addEventListener('click', function(e) {
            e.preventDefault();
            updateURL('all-picks');
            showSection('all-picks');
        });
    }
}

// Update URL parameters
function updateURL(section, week = null) {
    const url = new URL(window.location);
    url.searchParams.set('section', section);
    
    if (week && section === 'picks') {
        url.searchParams.set('week', week);
    } else {
        url.searchParams.delete('week');
    }
    
    window.history.pushState({}, '', url);
}

// Show a specific section
function showSection(section) {
    console.log('Showing section:', section);
    
    // Hide all sections
    const sections = ['dashboard', 'picks', 'leaderboard', 'all-picks'];
    sections.forEach(s => {
        const element = document.getElementById(`${s}-section`);
        if (element) {
            element.style.display = 'none';
        }
    });
    
    // Show selected section
    const targetSection = document.getElementById(`${section}-section`);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
    
    // Update navigation active state
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    const activeLink = document.getElementById(`${section}-link`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Load data for the section
    switch (section) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'picks':
            loadPicksData();
            break;
        case 'leaderboard':
            loadLeaderboardData();
            break;
        case 'all-picks':
            loadAllPicksData();
            break;
    }
}

// Setup modal
function setupModal() {
    console.log('Setting up modal...');
    
    const modal = document.getElementById('login-modal');
    const closeBtn = document.querySelector('.close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            if (modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Setup login form - FIXED VERSION
function setupLoginForm() {
    console.log('Setting up login form...');
    
    const loginButton = document.getElementById('login-button');
    const loginForm = document.getElementById('login-form');
    
    if (loginButton) {
        loginButton.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Login button clicked');
            const modal = document.getElementById('login-modal');
            if (modal) {
                modal.style.display = 'block';
            }
        });
    }
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Login form submitted');
            login();
        });
    }
}

// Login function - FIXED VERSION
async function login() {
    console.log('Login function called');
    
    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    
    if (!usernameInput || !passwordInput) {
        console.error('Login inputs not found');
        showToast('error', 'Login-Formular nicht gefunden');
        return;
    }
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    
    if (!username || !password) {
        showToast('error', 'Bitte Benutzername und Passwort eingeben');
        return;
    }
    
    try {
        showLoading();
        
        console.log('Sending login request for:', username);
        
        const response = await fetch(`${API_BASE}/api/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        console.log('Login response:', data);
        
        if (response.ok && data.user) {
            // Store user data
            currentUser = data.user;
            localStorage.setItem('user', JSON.stringify(currentUser));
            
            // Update UI
            updateAuthUI();
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            
            // Hide modal
            const modal = document.getElementById('login-modal');
            if (modal) {
                modal.style.display = 'none';
            }
            
            // Show success message
            showToast('success', 'Login erfolgreich');
            
            // Reload dashboard data
            loadDashboardData();
        } else {
            showToast('error', data.error || 'Login fehlgeschlagen');
        }
    } catch (error) {
        console.error('Error during login:', error);
        showToast('error', 'Ein Fehler ist aufgetreten');
    } finally {
        hideLoading();
    }
}

// Logout function
async function logout() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/auth/logout`, {
            method: 'POST'
        });
        
        if (response.ok) {
            // Clear user data
            currentUser = null;
            localStorage.removeItem('user');
            
            // Update UI
            updateAuthUI();
            
            // Show success message
            showToast('success', 'Logout erfolgreich');
            
            // Go back to dashboard
            showSection('dashboard');
        } else {
            showToast('error', 'Logout fehlgeschlagen');
        }
    } catch (error) {
        console.error('Error during logout:', error);
        showToast('error', 'Ein Fehler ist aufgetreten');
    } finally {
        hideLoading();
    }
}

// Check authentication status - FIXED VERSION
async function checkAuthStatus() {
    console.log('Checking auth status...');
    
    try {
        // First check localStorage
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            try {
                currentUser = JSON.parse(storedUser);
                console.log('Found stored user:', currentUser.username);
                updateAuthUI();
                return;
            } catch (e) {
                console.error('Error parsing stored user:', e);
                localStorage.removeItem('user');
            }
        }
        
        // If no stored user or parsing failed, check with server
        const response = await fetch(`${API_BASE}/api/auth/me`);
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.user) {
                currentUser = data.user;
                localStorage.setItem('user', JSON.stringify(currentUser));
                console.log('Server confirmed user:', currentUser.username);
                updateAuthUI();
            }
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
    }
}

// Update authentication UI - FIXED VERSION
function updateAuthUI() {
    console.log('Updating auth UI, current user:', currentUser);
    
    const userDetails = document.getElementById('user-details');
    const loginButton = document.getElementById('login-button');
    const usernameElement = document.getElementById('username');
    const logoutButton = document.getElementById('logout-button');
    
    if (currentUser) {
        console.log('Showing user details for:', currentUser.username);
        
        if (userDetails) {
            userDetails.style.display = 'flex';
        }
        if (loginButton) {
            loginButton.style.display = 'none';
        }
        if (usernameElement) {
            usernameElement.textContent = currentUser.username;
        }
        
        // Add logout event listener
        if (logoutButton) {
            logoutButton.removeEventListener('click', logout); // Remove existing listener
            logoutButton.addEventListener('click', logout);
        }
    } else {
        console.log('Showing login button');
        
        if (userDetails) {
            userDetails.style.display = 'none';
        }
        if (loginButton) {
            loginButton.style.display = 'block';
        }
    }
}

// Get current week
async function getCurrentWeek() {
    try {
        const response = await fetch(`${API_BASE}/api/current-week`);
        if (response.ok) {
            const data = await response.json();
            currentWeek = data.current_week;
            console.log('Current week:', currentWeek);
            
            // Update current week display
            const currentWeekElement = document.getElementById('current-week');
            if (currentWeekElement) {
                currentWeekElement.textContent = currentWeek;
            }
        }
    } catch (error) {
        console.error('Error getting current week:', error);
    }
}

// Load dashboard data
async function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    if (!currentUser) {
        console.log('No user logged in, showing default dashboard');
        return;
    }
    
    try {
        // Update user score
        const scoreElement = document.getElementById('user-score');
        if (scoreElement) {
            scoreElement.textContent = currentUser.score || 0;
        }
        
        // Load opponent scores
        await loadOpponentScores();
        
        // Load recent picks
        await loadRecentPicks();
        
        // Load eliminated teams
        await loadEliminatedTeams();
        
        // Load user rank
        await loadUserRank();
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Load opponent scores
async function loadOpponentScores() {
    try {
        const response = await fetch(`${API_BASE}/api/leaderboard`);
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('opponent-scores');
            
            if (container && data.leaderboard) {
                const opponents = data.leaderboard.filter(user => user.id !== currentUser.id);
                
                if (opponents.length === 0) {
                    container.innerHTML = '<p>Keine anderen Spieler</p>';
                    return;
                }
                
                container.innerHTML = opponents.map(opponent => `
                    <div class="opponent-score">
                        <span class="opponent-name">${opponent.username}</span>
                        <span class="opponent-points">${opponent.score}</span>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading opponent scores:', error);
        const container = document.getElementById('opponent-scores');
        if (container) {
            container.innerHTML = '<p>Fehler beim Laden</p>';
        }
    }
}

// Load recent picks
async function loadRecentPicks() {
    try {
        const response = await fetch(`${API_BASE}/api/picks/user/${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('recent-picks');
            
            if (container && data.picks) {
                if (data.picks.length === 0) {
                    container.innerHTML = '<p>Noch keine Picks gemacht</p>';
                    return;
                }
                
                // Show last 3 picks
                const recentPicks = data.picks.slice(-3).reverse();
                
                container.innerHTML = recentPicks.map(pick => {
                    const resultClass = pick.is_correct === null ? 'pending' : 
                                       pick.is_correct ? 'correct' : 'incorrect';
                    const resultText = pick.is_correct === null ? 'Ausstehend' :
                                      pick.is_correct ? 'Richtig' : 'Falsch';
                    
                    return `
                        <div class="recent-pick">
                            <img src="${pick.chosen_team.logo_url}" alt="${pick.chosen_team.name}" class="team-logo-small">
                            <div class="recent-pick-info">
                                <div class="recent-pick-week">Woche ${pick.match.week}</div>
                                <div class="recent-pick-team">${pick.chosen_team.name}</div>
                            </div>
                            <span class="recent-pick-result ${resultClass}">${resultText}</span>
                        </div>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        console.error('Error loading recent picks:', error);
        const container = document.getElementById('recent-picks');
        if (container) {
            container.innerHTML = '<p>Fehler beim Laden</p>';
        }
    }
}

// Load eliminated teams
async function loadEliminatedTeams() {
    try {
        const response = await fetch(`${API_BASE}/api/picks/eliminated?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('eliminated-teams');
            
            if (container && data.eliminated_teams) {
                if (data.eliminated_teams.length === 0) {
                    container.innerHTML = '<p>Keine eliminierten Teams</p>';
                    return;
                }
                
                container.innerHTML = data.eliminated_teams.map(team => `
                    <div class="eliminated-team">
                        <img src="${team.logo_url}" alt="${team.name}" class="eliminated-team-logo">
                        <span class="eliminated-team-name">${team.name}</span>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading eliminated teams:', error);
        const container = document.getElementById('eliminated-teams');
        if (container) {
            container.innerHTML = '<p>Fehler beim Laden</p>';
        }
    }
}

// Load user rank
async function loadUserRank() {
    try {
        const response = await fetch(`${API_BASE}/api/leaderboard`);
        if (response.ok) {
            const data = await response.json();
            const rankElement = document.getElementById('user-rank');
            
            if (rankElement && data.leaderboard) {
                const userIndex = data.leaderboard.findIndex(user => user.id === currentUser.id);
                const rank = userIndex >= 0 ? userIndex + 1 : '-';
                rankElement.textContent = rank;
            }
        }
    } catch (error) {
        console.error('Error loading user rank:', error);
    }
}

// Load picks data
async function loadPicksData(week = null) {
    if (!currentUser) {
        showToast('error', 'Bitte zuerst einloggen');
        return;
    }
    
    const targetWeek = week || currentWeek;
    
    try {
        // Load matches for the week
        await loadMatchesForWeek(targetWeek);
        
        // Update week selector
        const weekSelect = document.getElementById('week-select');
        if (weekSelect) {
            weekSelect.value = targetWeek;
        }
        
    } catch (error) {
        console.error('Error loading picks data:', error);
    }
}

// Load matches for week
async function loadMatchesForWeek(week) {
    try {
        const [matchesResponse, teamUsageResponse] = await Promise.all([
            fetch(`${API_BASE}/api/matches?week=${week}`),
            fetch(`${API_BASE}/api/picks/team-usage?user_id=${currentUser.id}`)
        ]);
        
        if (matchesResponse.ok && teamUsageResponse.ok) {
            const matchesData = await matchesResponse.json();
            const teamUsageData = await teamUsageResponse.json();
            
            const container = document.getElementById('matches-container');
            if (container && matchesData.matches) {
                
                // Create team usage lookup
                const teamUsage = {};
                teamUsageData.team_usage.forEach(usage => {
                    teamUsage[usage.team.id] = usage;
                });
                
                container.innerHTML = matchesData.matches.map(match => {
                    const homeUsage = teamUsage[match.home_team.id];
                    const awayUsage = teamUsage[match.away_team.id];
                    
                    const homeAvailable = homeUsage.status !== 'max_used';
                    const awayAvailable = awayUsage.status !== 'max_used';
                    
                    return `
                        <div class="match-card ${match.is_game_started ? 'game-started' : ''}" data-match-id="${match.id}">
                            <div class="match-header">
                                ${match.start_time_vienna} ${match.is_game_started ? '<span class="game-started-info">Spiel gestartet</span>' : ''}
                            </div>
                            <div class="match-button ${match.is_game_started ? 'disabled' : ''}" onclick="openPickModal(${match.id})">
                                <div class="match-teams-display">
                                    <div class="team-display ${!awayAvailable ? 'team-unavailable' : ''}">
                                        <img src="${match.away_team.logo_url}" alt="${match.away_team.name}" class="team-logo-large">
                                        <div class="team-name">${match.away_team.name}</div>
                                        ${!awayAvailable ? '<div class="unavailable-overlay">Nicht verfügbar</div>' : ''}
                                    </div>
                                    <div class="match-vs">@</div>
                                    <div class="team-display ${!homeAvailable ? 'team-unavailable' : ''}">
                                        <img src="${match.home_team.logo_url}" alt="${match.home_team.name}" class="team-logo-large">
                                        <div class="team-name">${match.home_team.name}</div>
                                        ${!homeAvailable ? '<div class="unavailable-overlay">Nicht verfügbar</div>' : ''}
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        console.error('Error loading matches:', error);
    }
}

// Initialize pick modal
function initializePickModal() {
    // Pick modal will be initialized when needed
}

// Open pick modal
function openPickModal(matchId) {
    console.log('Opening pick modal for match:', matchId);
    // Implementation for pick modal
}

// Load leaderboard data
async function loadLeaderboardData() {
    try {
        const response = await fetch(`${API_BASE}/api/leaderboard`);
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('leaderboard-container');
            
            if (container && data.leaderboard) {
                container.innerHTML = data.leaderboard.map((user, index) => `
                    <div class="leaderboard-entry">
                        <div class="leaderboard-rank">${index + 1}</div>
                        <div class="leaderboard-username">${user.username}</div>
                        <div class="leaderboard-score">${user.score}</div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
    }
}

// Load all picks data
async function loadAllPicksData() {
    try {
        const response = await fetch(`${API_BASE}/api/picks/all`);
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('all-picks-container');
            
            if (container && data.picks) {
                container.innerHTML = data.picks.map(pick => {
                    const resultClass = pick.is_correct === null ? 'pending' : 
                                       pick.is_correct ? 'correct' : 'incorrect';
                    const resultText = pick.is_correct === null ? 'Ausstehend' :
                                      pick.is_correct ? 'Richtig' : 'Falsch';
                    
                    return `
                        <div class="all-picks-entry">
                            <div class="all-picks-user">${pick.user.username}</div>
                            <div class="all-picks-team">
                                <img src="${pick.chosen_team.logo_url}" alt="${pick.chosen_team.name}" class="team-logo-small">
                                ${pick.chosen_team.name}
                            </div>
                            <div class="all-picks-result ${resultClass}">${resultText}</div>
                        </div>
                    `;
                }).join('');
            }
        }
    } catch (error) {
        console.error('Error loading all picks:', error);
    }
}

// Utility functions
function showLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'block';
    }
}

function hideLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'none';
    }
}

function showToast(type, message) {
    console.log(`Toast ${type}:`, message);
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type} show`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

