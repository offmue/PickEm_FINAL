// NFL PickEm 2025 - Fixed JavaScript with Login and Responsive Support
let currentUser = null;
let currentWeek = 2;
let currentSection = 'dashboard';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    console.log('App initializing...');
    
    // Check for existing user session
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            updateAuthUI();
        } catch (e) {
            console.error('Error parsing saved user:', e);
            localStorage.removeItem('user');
        }
    }
    
    // Initialize UI
    initializeUI();
    loadCurrentWeek();
    showSection('dashboard');
    
    console.log('App initialized successfully');
});

function initializeUI() {
    // Setup navigation
    setupNavigation();
    
    // Setup login/logout
    setupAuth();
    
    // Setup week selector
    setupWeekSelector();
    
    // Update auth UI
    updateAuthUI();
}

function setupNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const sectionName = this.id.replace('-link', '');
            showSection(sectionName);
            
            // Update active state
            navButtons.forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            });
            this.classList.add('active');
            this.setAttribute('aria-selected', 'true');
        });
    });
}

function setupAuth() {
    // Login button
    const loginButton = document.getElementById('login-button');
    if (loginButton) {
        loginButton.addEventListener('click', function() {
            console.log('Login button clicked');
            showLoginModal();
        });
    }
    
    // Logout button
    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            logout();
        });
    }
    
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Modal close
    const modal = document.getElementById('login-modal');
    const closeBtn = modal?.querySelector('.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            hideLoginModal();
        });
    }
    
    // Click outside modal to close
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                hideLoginModal();
            }
        });
    }
}

function setupWeekSelector() {
    const weekSelect = document.getElementById('week-select');
    if (weekSelect) {
        weekSelect.addEventListener('change', function() {
            const selectedWeek = parseInt(this.value);
            loadMatchesForWeek(selectedWeek);
        });
    }
}

function showLoginModal() {
    const modal = document.getElementById('login-modal');
    if (modal) {
        modal.style.display = 'block';
        modal.setAttribute('aria-hidden', 'false');
        
        // Focus first input
        const firstInput = modal.querySelector('input');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }
    }
}

function hideLoginModal() {
    const modal = document.getElementById('login-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
    }
}

async function handleLogin() {
    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    
    if (!usernameInput || !passwordInput) {
        console.error('Login inputs not found');
        return;
    }
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    
    if (!username || !password) {
        showToast('Bitte Benutzername und Passwort eingeben', 'error');
        return;
    }
    
    try {
        console.log('Attempting login for:', username);
        
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        console.log('Login response status:', response.status);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Login fehlgeschlagen' }));
            throw new Error(errorData.message || 'Login fehlgeschlagen');
        }
        
        const data = await response.json();
        console.log('Login successful:', data);
        
        if (data.user) {
            currentUser = data.user;
            localStorage.setItem('user', JSON.stringify(currentUser));
            
            // Hide modal
            hideLoginModal();
            
            // Update UI
            updateAuthUI();
            
            // Reload current section
            if (currentSection === 'dashboard') {
                loadDashboardData();
            }
            
            showToast('Login erfolgreich!', 'success');
        } else {
            throw new Error('Keine Benutzerdaten erhalten');
        }
        
    } catch (error) {
        console.error('Login error:', error);
        showToast(error.message || 'Login fehlgeschlagen', 'error');
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('user');
    updateAuthUI();
    showSection('dashboard');
    showToast('Erfolgreich abgemeldet', 'info');
}

function updateAuthUI() {
    const loginButton = document.getElementById('login-button');
    const logoutButton = document.getElementById('logout-button');
    const userDetails = document.getElementById('user-details');
    const usernameSpan = document.getElementById('username');
    
    if (currentUser) {
        // User is logged in
        if (loginButton) loginButton.style.display = 'none';
        if (userDetails) userDetails.style.display = 'flex';
        if (usernameSpan) usernameSpan.textContent = currentUser.username;
    } else {
        // User is not logged in
        if (loginButton) loginButton.style.display = 'inline-flex';
        if (userDetails) userDetails.style.display = 'none';
    }
}

async function loadCurrentWeek() {
    try {
        const response = await fetch('/api/current-week');
        if (response.ok) {
            const data = await response.json();
            currentWeek = data.current_week;
            
            const currentWeekSpan = document.getElementById('current-week');
            if (currentWeekSpan) {
                currentWeekSpan.textContent = currentWeek;
            }
            
            // Update week selector
            const weekSelect = document.getElementById('week-select');
            if (weekSelect) {
                weekSelect.value = currentWeek;
            }
            
            console.log('Current week:', currentWeek);
        }
    } catch (error) {
        console.error('Error loading current week:', error);
    }
}

function showSection(sectionName) {
    console.log('Showing section:', sectionName);
    currentSection = sectionName;
    
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionName + '-section');
    if (targetSection) {
        targetSection.style.display = 'block';
        
        // Load section data
        switch (sectionName) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'picks':
                loadPicksData();
                break;
            case 'leaderboard':
                loadLeaderboardData();
                break;
            case 'all-picks':
                loadAllPicksData();
                break;
        }
    }
}

async function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    if (!currentUser) {
        console.log('No user logged in, showing default dashboard');
        showDefaultDashboard();
        return;
    }
    
    try {
        // Load user stats
        await loadUserStats();
        
        // Load opponent scores
        await loadOpponentScores();
        
        // Load recent picks
        await loadRecentPicks();
        
        // Load eliminated teams
        await loadEliminatedTeams();
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

function showDefaultDashboard() {
    const userScore = document.getElementById('user-score');
    const userRank = document.getElementById('user-rank');
    const opponentScores = document.getElementById('opponent-scores');
    const recentPicks = document.getElementById('recent-picks');
    const eliminatedTeams = document.getElementById('eliminated-teams');
    
    if (userScore) userScore.textContent = '-';
    if (userRank) userRank.textContent = '-';
    if (opponentScores) opponentScores.innerHTML = 'Bitte einloggen um Punkte zu sehen';
    if (recentPicks) recentPicks.innerHTML = 'Bitte einloggen um Picks zu sehen';
    if (eliminatedTeams) eliminatedTeams.innerHTML = 'Bitte einloggen um eliminierte Teams zu sehen';
}

async function loadUserStats() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/user-stats?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            
            const userScore = document.getElementById('user-score');
            const userRank = document.getElementById('user-rank');
            
            if (userScore) userScore.textContent = data.total_points || 0;
            if (userRank) userRank.textContent = data.rank || '-';
        }
    } catch (error) {
        console.error('Error loading user stats:', error);
    }
}

async function loadOpponentScores() {
    try {
        const response = await fetch('/api/leaderboard');
        if (response.ok) {
            const data = await response.json();
            const opponentScores = document.getElementById('opponent-scores');
            
            if (opponentScores && data.leaderboard) {
                let html = '';
                data.leaderboard.forEach(user => {
                    if (!currentUser || user.username !== currentUser.username) {
                        html += `
                            <div class="opponent-score">
                                <span class="opponent-name">${user.username}</span>
                                <span class="opponent-points">${user.total_points}</span>
                            </div>
                        `;
                    }
                });
                opponentScores.innerHTML = html || 'Keine anderen Spieler';
            }
        }
    } catch (error) {
        console.error('Error loading opponent scores:', error);
    }
}

async function loadRecentPicks() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/picks/recent?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const recentPicks = document.getElementById('recent-picks');
            
            if (recentPicks) {
                if (data.picks && data.picks.length > 0) {
                    let html = '';
                    data.picks.slice(0, 3).forEach(pick => {
                        const result = pick.points > 0 ? '✅' : (pick.points === 0 ? '❌' : '⏳');
                        html += `
                            <div class="recent-pick">
                                <strong>Woche ${pick.week}:</strong> ${pick.team_name} ${result}
                            </div>
                        `;
                    });
                    recentPicks.innerHTML = html;
                } else {
                    recentPicks.innerHTML = 'Noch keine Picks gemacht';
                }
            }
        }
    } catch (error) {
        console.error('Error loading recent picks:', error);
    }
}

async function loadEliminatedTeams() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`/api/picks/eliminated?user_id=${currentUser.id}`);
        if (response.ok) {
            const data = await response.json();
            const eliminatedTeams = document.getElementById('eliminated-teams');
            
            if (eliminatedTeams) {
                if (data.eliminated_teams && data.eliminated_teams.length > 0) {
                    let html = '';
                    data.eliminated_teams.forEach(team => {
                        html += `
                            <div class="eliminated-team">
                                <img src="${team.logo_url}" alt="${team.name}" class="eliminated-team-logo">
                                <span>${team.name}</span>
                            </div>
                        `;
                    });
                    eliminatedTeams.innerHTML = html;
                } else {
                    eliminatedTeams.innerHTML = 'Keine Teams eliminiert';
                }
            }
        }
    } catch (error) {
        console.error('Error loading eliminated teams:', error);
    }
}

async function loadPicksData() {
    console.log('Loading picks data...');
    
    const weekSelect = document.getElementById('week-select');
    const selectedWeek = weekSelect ? parseInt(weekSelect.value) : currentWeek;
    
    await loadMatchesForWeek(selectedWeek);
}

async function loadMatchesForWeek(week) {
    console.log('Loading matches for week:', week);
    
    try {
        const matchesContainer = document.getElementById('matches-container');
        if (!matchesContainer) return;
        
        matchesContainer.innerHTML = '<div class="loading">Lade Spiele...</div>';
        
        const response = await fetch(`/api/matches?week=${week}`);
        if (!response.ok) {
            throw new Error('Failed to load matches');
        }
        
        const data = await response.json();
        
        if (!data.matches || data.matches.length === 0) {
            matchesContainer.innerHTML = '<div class="no-matches">Keine Spiele für diese Woche gefunden</div>';
            return;
        }
        
        // Get team usage data if user is logged in
        let teamUsage = {};
        if (currentUser) {
            try {
                const usageResponse = await fetch(`/api/picks/team-usage?user_id=${currentUser.id}`);
                if (usageResponse.ok) {
                    const usageData = await usageResponse.json();
                    usageData.team_usage.forEach(usage => {
                        teamUsage[usage.team.abbreviation] = usage.status;
                    });
                }
            } catch (error) {
                console.error('Error loading team usage:', error);
            }
        }
        
        // Render matches
        let html = '';
        data.matches.forEach(match => {
            html += renderMatchCard(match, teamUsage);
        });
        
        matchesContainer.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading matches:', error);
        const matchesContainer = document.getElementById('matches-container');
        if (matchesContainer) {
            matchesContainer.innerHTML = '<div class="error">Fehler beim Laden der Spiele</div>';
        }
    }
}

function renderMatchCard(match, teamUsage = {}) {
    const gameStarted = new Date(match.game_time) <= new Date();
    const homeTeamStatus = teamUsage[match.home_team.abbreviation] || 'available';
    const awayTeamStatus = teamUsage[match.away_team.abbreviation] || 'available';
    
    const homeTeamUnavailable = homeTeamStatus === 'eliminated' || homeTeamStatus === 'max_used';
    const awayTeamUnavailable = awayTeamStatus === 'eliminated' || awayTeamStatus === 'max_used';
    
    return `
        <div class="match-card ${gameStarted ? 'game-started' : ''}">
            <div class="match-header">
                <span>${new Date(match.game_time).toLocaleString('de-DE')}</span>
                ${gameStarted ? '<span class="game-started-info">Spiel gestartet</span>' : ''}
            </div>
            <div class="match-button ${gameStarted ? 'disabled' : ''}" 
                 onclick="${gameStarted ? '' : `openPickModal(${match.id})`}">
                <div class="match-teams-display">
                    <div class="team-display ${awayTeamUnavailable ? 'team-unavailable' : ''}" 
                         data-team="${match.away_team.abbreviation}">
                        <img src="${match.away_team.logo_url}" alt="${match.away_team.name}" class="team-logo-large">
                        <div class="team-name">${match.away_team.name}</div>
                        ${awayTeamUnavailable ? '<div class="unavailable-reason">Nicht verfügbar</div>' : ''}
                    </div>
                    <div class="match-vs">@</div>
                    <div class="team-display ${homeTeamUnavailable ? 'team-unavailable' : ''}" 
                         data-team="${match.home_team.abbreviation}">
                        <img src="${match.home_team.logo_url}" alt="${match.home_team.name}" class="team-logo-large">
                        <div class="team-name">${match.home_team.name}</div>
                        ${homeTeamUnavailable ? '<div class="unavailable-reason">Nicht verfügbar</div>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function openPickModal(matchId) {
    if (!currentUser) {
        showToast('Bitte zuerst einloggen', 'warning');
        return;
    }
    
    console.log('Opening pick modal for match:', matchId);
    // Pick modal functionality would go here
    showToast('Pick-Funktionalität wird implementiert', 'info');
}

async function loadLeaderboardData() {
    console.log('Loading leaderboard data...');
    
    try {
        const response = await fetch('/api/leaderboard');
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('leaderboard-container');
            
            if (container && data.leaderboard) {
                let html = '<div class="leaderboard-table">';
                data.leaderboard.forEach((user, index) => {
                    html += `
                        <div class="leaderboard-row">
                            <span class="rank">${index + 1}</span>
                            <span class="username">${user.username}</span>
                            <span class="points">${user.total_points}</span>
                        </div>
                    `;
                });
                html += '</div>';
                container.innerHTML = html;
            }
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
    }
}

async function loadAllPicksData() {
    console.log('Loading all picks data...');
    
    try {
        const response = await fetch('/api/picks/all');
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('all-picks-container');
            
            if (container) {
                container.innerHTML = 'Alle Picks werden geladen...';
                // Implementation for all picks display
            }
        }
    } catch (error) {
        console.error('Error loading all picks:', error);
    }
}

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    toastContainer.appendChild(toast);
    
    // Show toast
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Hide and remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

// Global functions for onclick handlers
window.openPickModal = openPickModal;

