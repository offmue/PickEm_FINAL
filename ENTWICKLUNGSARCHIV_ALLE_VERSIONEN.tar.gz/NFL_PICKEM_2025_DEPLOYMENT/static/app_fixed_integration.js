// NFL PickEm 2025 - Fixed Frontend Integration
let currentUser = null;
let currentWeek = 2;
let currentSection = 'dashboard';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    console.log('NFL PickEm App initializing...');
    
    // Wait for all elements to be ready
    setTimeout(function() {
        // Check for existing user session
        checkUserSession();
        
        // Initialize UI components
        initializeNavigation();
        initializeAuth();
        initializeCountdown();
        loadCurrentWeek();
        showSection('dashboard');
        
        console.log('NFL PickEm App initialized successfully');
    }, 200);
});

// Session Management
function checkUserSession() {
    fetch('/api/auth/check-session')
        .then(response => response.json())
        .then(data => {
            if (data.user) {
                currentUser = data.user;
                updateAuthUI();
                console.log('User session active:', currentUser.username);
            } else {
                currentUser = null;
                updateAuthUI();
            }
        })
        .catch(error => {
            console.error('Session check error:', error);
            currentUser = null;
            updateAuthUI();
        });
}

// Navigation Management
function initializeNavigation() {
    const navTabs = document.querySelectorAll('.nav-tab');
    
    navTabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            if (section) {
                showSection(section);
                
                // Update active tab
                navTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
}

// Authentication Management - FIXED
function initializeAuth() {
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const loginModal = document.getElementById('login-modal');
    const modalClose = document.getElementById('modal-close');
    const loginForm = document.getElementById('login-form');
    
    console.log('Initializing auth with elements:', {
        loginBtn: !!loginBtn,
        logoutBtn: !!logoutBtn,
        loginModal: !!loginModal,
        modalClose: !!modalClose,
        loginForm: !!loginForm
    });
    
    // Login button - FIXED
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Login button clicked');
            if (loginModal) {
                loginModal.style.display = 'flex';
                // Focus on username field
                const usernameField = document.getElementById('username');
                if (usernameField) {
                    setTimeout(() => usernameField.focus(), 100);
                }
            }
        });
    }
    
    // Logout button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
    
    // Modal close - FIXED
    if (modalClose) {
        modalClose.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Modal close clicked');
            if (loginModal) {
                loginModal.style.display = 'none';
            }
        });
    }
    
    // Login form - FIXED
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Login form submitted');
            
            const usernameField = document.getElementById('username');
            const passwordField = document.getElementById('password');
            
            if (usernameField && passwordField) {
                const username = usernameField.value.trim();
                const password = passwordField.value.trim();
                
                if (username && password) {
                    console.log('Login attempt:', username);
                    login(username, password);
                } else {
                    alert('Bitte Benutzername und Passwort eingeben');
                }
            }
        });
    }
    
    // Close modal on outside click
    if (loginModal) {
        loginModal.addEventListener('click', function(e) {
            if (e.target === loginModal) {
                loginModal.style.display = 'none';
            }
        });
    }
}

// Login Function - FIXED
function login(username, password) {
    console.log('Attempting login for:', username);
    
    fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Login response:', data);
        
        if (data.user) {
            currentUser = data.user;
            
            // Close modal
            const loginModal = document.getElementById('login-modal');
            if (loginModal) {
                loginModal.style.display = 'none';
            }
            
            // Clear form
            const loginForm = document.getElementById('login-form');
            if (loginForm) {
                loginForm.reset();
            }
            
            // Update UI
            updateAuthUI();
            
            // Reload current section data
            showSection(currentSection);
            
            console.log('Login successful for:', currentUser.username);
        } else {
            alert('Login fehlgeschlagen: ' + (data.message || 'Unbekannter Fehler'));
        }
    })
    .catch(error => {
        console.error('Login error:', error);
        alert('Login-Fehler: Verbindung zum Server fehlgeschlagen');
    });
}

// Logout Function
function logout() {
    fetch('/api/auth/logout', {
        method: 'POST'
    })
    .then(() => {
        currentUser = null;
        updateAuthUI();
        showSection('dashboard');
        console.log('Logout successful');
    })
    .catch(error => {
        console.error('Logout error:', error);
        // Force logout even if server request fails
        currentUser = null;
        updateAuthUI();
        showSection('dashboard');
    });
}

// Update Auth UI - FIXED
function updateAuthUI() {
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const userSection = document.querySelector('.user-section');
    
    if (currentUser) {
        // User is logged in
        if (loginBtn) loginBtn.style.display = 'none';
        if (logoutBtn) {
            logoutBtn.style.display = 'inline-block';
            logoutBtn.textContent = currentUser.username;
        }
        if (userSection) {
            userSection.innerHTML = `<span>${currentUser.username}</span> <button id="logout-btn" class="logout-btn">Logout</button>`;
            // Re-attach logout handler
            const newLogoutBtn = document.getElementById('logout-btn');
            if (newLogoutBtn) {
                newLogoutBtn.addEventListener('click', logout);
            }
        }
    } else {
        // User is not logged in
        if (loginBtn) loginBtn.style.display = 'inline-block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (userSection) {
            userSection.innerHTML = '<button id="login-btn" class="login-btn">Login</button>';
            // Re-attach login handler
            const newLoginBtn = document.getElementById('login-btn');
            if (newLoginBtn) {
                newLoginBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const loginModal = document.getElementById('login-modal');
                    if (loginModal) {
                        loginModal.style.display = 'flex';
                    }
                });
            }
        }
    }
}

// Countdown Timer
function initializeCountdown() {
    updateCountdown();
    setInterval(updateCountdown, 1000);
}

function updateCountdown() {
    const now = new Date();
    const nextSunday = getNextSunday();
    const timeDiff = nextSunday - now;
    
    if (timeDiff > 0) {
        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
        
        updateCountdownDisplay(days, hours, minutes, seconds);
    }
}

function getNextSunday() {
    const now = new Date();
    const nextSunday = new Date(now);
    nextSunday.setDate(now.getDate() + (7 - now.getDay()));
    nextSunday.setHours(19, 0, 0, 0); // 19:00 Uhr
    
    // If it's already past Sunday 19:00, get next Sunday
    if (now.getDay() === 0 && now.getHours() >= 19) {
        nextSunday.setDate(nextSunday.getDate() + 7);
    }
    
    return nextSunday;
}

function updateCountdownDisplay(days, hours, minutes, seconds) {
    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');
    
    if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
    if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
    if (minutesEl) minutesEl.textContent = String(minutes).padStart(2, '0');
    if (secondsEl) secondsEl.textContent = String(seconds).padStart(2, '0');
}

// Load Current Week - FIXED
function loadCurrentWeek() {
    fetch('/api/current-week')
        .then(response => response.json())
        .then(data => {
            if (data.week) {
                currentWeek = data.week;
                console.log('Current week loaded:', currentWeek);
                
                // Update week selector
                const weekSelect = document.getElementById('week-select');
                if (weekSelect) {
                    weekSelect.value = currentWeek;
                }
            }
        })
        .catch(error => {
            console.error('Error loading current week:', error);
        });
}

// Section Management - FIXED
function showSection(sectionName) {
    console.log('Showing section:', sectionName);
    
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionName + '-section');
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionName;
        
        // Load section-specific data
        switch (sectionName) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'picks':
                loadPicksData();
                break;
            case 'leaderboard':
                loadLeaderboardData();
                break;
            case 'all-picks':
                loadAllPicksData();
                break;
        }
    }
}

// Dashboard Data Loading - FIXED
function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    if (!currentUser) {
        // Show login prompts
        updateDashboardForGuest();
        return;
    }
    
    // Load user stats
    Promise.all([
        fetch('/api/user/stats').then(r => r.json()),
        fetch('/api/picks/eliminated').then(r => r.json()),
        fetch('/api/leaderboard').then(r => r.json())
    ])
    .then(([stats, eliminated, leaderboard]) => {
        updateDashboardStats(stats);
        updateEliminatedTeams(eliminated);
        updateDashboardLeaderboard(leaderboard);
    })
    .catch(error => {
        console.error('Error loading dashboard data:', error);
    });
}

function updateDashboardForGuest() {
    const pointsEl = document.querySelector('.points-value');
    const rankEl = document.querySelector('.rank-value');
    const eliminatedEl = document.querySelector('.eliminated-teams-list');
    
    if (pointsEl) pointsEl.textContent = '0';
    if (rankEl) rankEl.textContent = '-';
    if (eliminatedEl) eliminatedEl.innerHTML = '<p>Bitte einloggen um eliminierte Teams zu sehen</p>';
}

function updateDashboardStats(stats) {
    const pointsEl = document.querySelector('.points-value');
    const rankEl = document.querySelector('.rank-value');
    
    if (pointsEl && stats.points !== undefined) {
        pointsEl.textContent = stats.points;
    }
    if (rankEl && stats.rank !== undefined) {
        rankEl.textContent = stats.rank;
    }
}

function updateEliminatedTeams(eliminated) {
    const eliminatedEl = document.querySelector('.eliminated-teams-list');
    if (!eliminatedEl) return;
    
    if (!eliminated.eliminated_teams || eliminated.eliminated_teams.length === 0) {
        eliminatedEl.innerHTML = '<p>Keine eliminierten Teams</p>';
        return;
    }
    
    const teamsHtml = eliminated.eliminated_teams.map(team => 
        `<div class="eliminated-team">
            <img src="${team.logo_url}" alt="${team.name}" class="team-logo-small">
            <span>${team.name}</span>
        </div>`
    ).join('');
    
    eliminatedEl.innerHTML = teamsHtml;
}

// Picks Data Loading - FIXED
function loadPicksData() {
    console.log('Loading picks data...');
    
    if (!currentUser) {
        const picksContent = document.querySelector('.picks-content');
        if (picksContent) {
            picksContent.innerHTML = '<p>Bitte einloggen um Picks zu sehen</p>';
        }
        return;
    }
    
    // Initialize week selector
    const weekSelect = document.getElementById('week-select');
    if (weekSelect) {
        weekSelect.addEventListener('change', function() {
            const selectedWeek = parseInt(this.value);
            loadMatchesForWeek(selectedWeek);
        });
        
        // Load current week matches
        loadMatchesForWeek(currentWeek);
    }
}

// Load Matches for Week - FIXED
function loadMatchesForWeek(week) {
    console.log('Loading matches for week:', week);
    
    const matchesContainer = document.querySelector('.matches-container');
    if (matchesContainer) {
        matchesContainer.innerHTML = '<p>Lade Spiele...</p>';
    }
    
    if (!currentUser) {
        if (matchesContainer) {
            matchesContainer.innerHTML = '<p>Bitte einloggen um Spiele zu sehen</p>';
        }
        return;
    }
    
    Promise.all([
        fetch(`/api/matches?week=${week}`).then(r => r.json()),
        fetch('/api/picks/team-usage').then(r => r.json()),
        fetch('/api/picks/eliminated').then(r => r.json())
    ])
    .then(([matches, teamUsage, eliminated]) => {
        displayMatches(matches, teamUsage, eliminated, week);
    })
    .catch(error => {
        console.error('Error loading matches:', error);
        if (matchesContainer) {
            matchesContainer.innerHTML = '<p>Fehler beim Laden der Spiele</p>';
        }
    });
}

function displayMatches(matches, teamUsage, eliminated, week) {
    const matchesContainer = document.querySelector('.matches-container');
    if (!matchesContainer) return;
    
    if (!matches.matches || matches.matches.length === 0) {
        matchesContainer.innerHTML = '<p>Keine Spiele für diese Woche gefunden</p>';
        return;
    }
    
    const eliminatedTeamIds = eliminated.eliminated_teams ? 
        eliminated.eliminated_teams.map(team => team.id) : [];
    
    const teamUsageMap = {};
    if (teamUsage.team_usage) {
        teamUsage.team_usage.forEach(usage => {
            teamUsageMap[usage.team.id] = usage.usage_count;
        });
    }
    
    const matchesHtml = matches.matches.map(match => {
        const homeAvailable = !eliminatedTeamIds.includes(match.homeTeam.id) && 
                             (teamUsageMap[match.homeTeam.id] || 0) < 2;
        const awayAvailable = !eliminatedTeamIds.includes(match.awayTeam.id) && 
                             (teamUsageMap[match.awayTeam.id] || 0) < 2;
        
        return `
            <div class="match-card">
                <div class="match-teams">
                    <div class="team ${homeAvailable ? 'available' : 'unavailable'}" 
                         onclick="${homeAvailable ? `selectTeam(${match.id}, ${match.homeTeam.id})` : ''}">
                        <img src="${match.homeTeam.logo_url}" alt="${match.homeTeam.name}" class="team-logo">
                        <span>${match.homeTeam.name}</span>
                        ${!homeAvailable ? '<span class="unavailable-reason">Nicht verfügbar</span>' : ''}
                    </div>
                    <div class="vs">vs</div>
                    <div class="team ${awayAvailable ? 'available' : 'unavailable'}" 
                         onclick="${awayAvailable ? `selectTeam(${match.id}, ${match.awayTeam.id})` : ''}">
                        <img src="${match.awayTeam.logo_url}" alt="${match.awayTeam.name}" class="team-logo">
                        <span>${match.awayTeam.name}</span>
                        ${!awayAvailable ? '<span class="unavailable-reason">Nicht verfügbar</span>' : ''}
                    </div>
                </div>
                <div class="match-info">
                    <div class="match-time">${new Date(match.game_time).toLocaleString('de-DE')}</div>
                </div>
            </div>
        `;
    }).join('');
    
    matchesContainer.innerHTML = matchesHtml;
}

// Team Selection
function selectTeam(matchId, teamId) {
    if (!currentUser) {
        alert('Bitte einloggen um einen Pick zu machen');
        return;
    }
    
    if (confirm('Möchten Sie dieses Team als Ihren Pick auswählen?')) {
        fetch('/api/picks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                match_id: matchId,
                team_id: teamId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Pick erfolgreich gespeichert!');
                // Reload matches to show updated availability
                const weekSelect = document.getElementById('week-select');
                if (weekSelect) {
                    loadMatchesForWeek(parseInt(weekSelect.value));
                }
            } else {
                alert('Fehler beim Speichern des Picks: ' + (data.message || 'Unbekannter Fehler'));
            }
        })
        .catch(error => {
            console.error('Error saving pick:', error);
            alert('Fehler beim Speichern des Picks');
        });
    }
}

// Leaderboard Data Loading - FIXED
function loadLeaderboardData() {
    console.log('Loading leaderboard data...');
    
    const leaderboardContainer = document.querySelector('.leaderboard-container');
    if (leaderboardContainer) {
        leaderboardContainer.innerHTML = '<p>Lade Rangliste...</p>';
    }
    
    fetch('/api/leaderboard')
        .then(response => response.json())
        .then(data => {
            displayLeaderboard(data);
        })
        .catch(error => {
            console.error('Error loading leaderboard:', error);
            if (leaderboardContainer) {
                leaderboardContainer.innerHTML = '<p>Fehler beim Laden der Rangliste</p>';
            }
        });
}

function displayLeaderboard(data) {
    const leaderboardContainer = document.querySelector('.leaderboard-container');
    if (!leaderboardContainer) return;
    
    if (!data.leaderboard || data.leaderboard.length === 0) {
        leaderboardContainer.innerHTML = '<p>Keine Rangliste verfügbar</p>';
        return;
    }
    
    const leaderboardHtml = `
        <table class="leaderboard-table">
            <thead>
                <tr>
                    <th>Rang</th>
                    <th>Spieler</th>
                    <th>Punkte</th>
                </tr>
            </thead>
            <tbody>
                ${data.leaderboard.map((player, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${player.username}</td>
                        <td>${player.points}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    leaderboardContainer.innerHTML = leaderboardHtml;
}

// All Picks Data Loading - FIXED
function loadAllPicksData() {
    console.log('Loading all picks data...');
    
    const allPicksContainer = document.querySelector('.all-picks-container');
    if (allPicksContainer) {
        allPicksContainer.innerHTML = '<p>Lade alle Picks...</p>';
    }
    
    fetch('/api/picks/all')
        .then(response => response.json())
        .then(data => {
            displayAllPicks(data);
        })
        .catch(error => {
            console.error('Error loading all picks:', error);
            if (allPicksContainer) {
                allPicksContainer.innerHTML = '<p>Fehler beim Laden der Picks</p>';
            }
        });
}

function displayAllPicks(data) {
    const allPicksContainer = document.querySelector('.all-picks-container');
    if (!allPicksContainer) return;
    
    if (!data.picks || data.picks.length === 0) {
        allPicksContainer.innerHTML = '<p>Keine Picks verfügbar</p>';
        return;
    }
    
    // Group picks by week
    const picksByWeek = {};
    data.picks.forEach(pick => {
        if (!picksByWeek[pick.week]) {
            picksByWeek[pick.week] = [];
        }
        picksByWeek[pick.week].push(pick);
    });
    
    const allPicksHtml = Object.keys(picksByWeek)
        .sort((a, b) => parseInt(a) - parseInt(b))
        .map(week => `
            <div class="week-picks">
                <h3>Woche ${week}</h3>
                <div class="picks-grid">
                    ${picksByWeek[week].map(pick => `
                        <div class="pick-card">
                            <div class="pick-user">${pick.username}</div>
                            <div class="pick-team">
                                <img src="${pick.team_logo}" alt="${pick.team_name}" class="team-logo-small">
                                <span>${pick.team_name}</span>
                            </div>
                            <div class="pick-result ${pick.result || 'pending'}">${pick.points || 0} Punkte</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    
    allPicksContainer.innerHTML = allPicksHtml;
}

console.log('NFL PickEm App JavaScript loaded successfully');

