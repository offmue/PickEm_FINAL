// Pick Modal Functionality - moved to app.js

