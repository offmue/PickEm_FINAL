// NFL PickEm - Original Design Compatible JavaScript

let currentUser = null;
let currentWeek = 2;
let currentSection = 'dashboard';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    console.log('NFL PickEm App initializing...');
    
    // Wait a bit more for all elements to be ready
    setTimeout(function() {
        // Check for existing user session
        const savedUser = localStorage.getItem('nfl_pickem_user');
        if (savedUser) {
            try {
                currentUser = JSON.parse(savedUser);
                updateAuthUI();
                console.log('User session restored:', currentUser.username);
            } catch (e) {
                console.error('Error parsing saved user:', e);
                localStorage.removeItem('nfl_pickem_user');
            }
        }
        
        // Initialize UI components
        initializeNavigation();
        initializeAuth();
        initializeCountdown();
        loadCurrentWeek();
        showSection('dashboard');
        
        console.log('NFL PickEm App initialized successfully');
    }, 100);
});

// Navigation Management
function initializeNavigation() {
    const navTabs = document.querySelectorAll('.nav-tab');
    
    // Add click handlers to navigation tabs
    navTabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            if (section) {
                showSection(section);
                
                // Update active tab
                navTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
}

// Authentication Management
function initializeAuth() {
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const loginModal = document.getElementById('login-modal');
    const modalClose = document.getElementById('modal-close');
    const loginForm = document.getElementById('login-form');
    
    console.log('Initializing auth with elements:', {
        loginBtn: !!loginBtn,
        logoutBtn: !!logoutBtn,
        loginModal: !!loginModal,
        modalClose: !!modalClose,
        loginForm: !!loginForm
    });
    
    // Login button
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            console.log('Login button clicked');
            if (loginModal) {
                loginModal.style.display = 'flex';
            }
        });
    }
    
    // Logout button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            logout();
        });
    }
    
    // Modal close
    if (modalClose) {
        modalClose.addEventListener('click', function() {
            console.log('Modal close clicked');
            if (loginModal) {
                loginModal.style.display = 'none';
            }
        });
    }
    
    // Login form
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Login form submitted');
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            console.log('Login attempt:', username);
            login(username, password);
        });
    }
    
    // Close modal on outside click
    if (loginModal) {
        loginModal.addEventListener('click', function(e) {
            if (e.target === loginModal) {
                loginModal.style.display = 'none';
            }
        });
    }
}

// Countdown Timer
function initializeCountdown() {
    updateCountdown();
    setInterval(updateCountdown, 1000);
}

function updateCountdown() {
    const now = new Date();
    const nextSunday = getNextSunday();
    const timeDiff = nextSunday - now;
    
    if (timeDiff > 0) {
        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
        
        updateCountdownDisplay(days, hours, minutes, seconds);
    }
}

function getNextSunday() {
    const now = new Date();
    const nextSunday = new Date(now);
    nextSunday.setDate(now.getDate() + (7 - now.getDay()));
    nextSunday.setHours(19, 0, 0, 0); // 19:00 Uhr
    
    // If it's already past Sunday 19:00, get next Sunday
    if (now.getDay() === 0 && now.getHours() >= 19) {
        nextSunday.setDate(nextSunday.getDate() + 7);
    }
    
    return nextSunday;
}

function updateCountdownDisplay(days, hours, minutes, seconds) {
    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');
    
    if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
    if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
    if (minutesEl) minutesEl.textContent = String(minutes).padStart(2, '0');
    if (secondsEl) secondsEl.textContent = String(seconds).padStart(2, '0');
}

// Section Management
function showSection(sectionName) {
    console.log('Showing section:', sectionName);
    
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionName + '-section');
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionName;
        
        // Load section-specific data
        switch (sectionName) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'picks':
                loadPicksData();
                break;
            case 'leaderboard':
                loadLeaderboardData();
                break;
            case 'all-picks':
                loadAllPicksData();
                break;
        }
    }
}

// Authentication Functions
async function login(username, password) {
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            localStorage.setItem('nfl_pickem_user', JSON.stringify(currentUser));
            updateAuthUI();
            
            // Close modal
            const loginModal = document.getElementById('login-modal');
            if (loginModal) {
                loginModal.style.display = 'none';
            }
            
            // Clear form
            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
            
            showToast('Erfolgreich angemeldet!', 'success');
            
            // Reload current section data
            showSection(currentSection);
        } else {
            showToast(data.error || 'Login fehlgeschlagen', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('Verbindungsfehler', 'error');
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('nfl_pickem_user');
    updateAuthUI();
    showToast('Erfolgreich abgemeldet', 'success');
    
    // Reload current section
    showSection(currentSection);
}

function updateAuthUI() {
    const loginBtn = document.getElementById('login-btn');
    const userInfo = document.getElementById('user-info');
    const usernameDisplay = document.getElementById('username-display');
    
    if (currentUser) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (userInfo) userInfo.style.display = 'flex';
        if (usernameDisplay) usernameDisplay.textContent = currentUser.username;
    } else {
        if (loginBtn) loginBtn.style.display = 'block';
        if (userInfo) userInfo.style.display = 'none';
    }
}

// Data Loading Functions
async function loadCurrentWeek() {
    try {
        const response = await fetch('/api/current-week');
        const data = await response.json();
        if (response.ok) {
            currentWeek = data.week;
            const currentWeekEl = document.getElementById('current-week');
            if (currentWeekEl) {
                currentWeekEl.textContent = currentWeek;
            }
        }
    } catch (error) {
        console.error('Error loading current week:', error);
    }
}

async function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    if (!currentUser) {
        // Show login prompts
        return;
    }
    
    try {
        // Load user points
        const pointsResponse = await fetch(`/api/leaderboard`);
        const pointsData = await pointsResponse.json();
        
        if (pointsResponse.ok) {
            const userEntry = pointsData.find(entry => entry.username === currentUser.username);
            if (userEntry) {
                const userPointsEl = document.getElementById('user-points');
                const userRankEl = document.getElementById('user-rank');
                
                if (userPointsEl) userPointsEl.textContent = userEntry.total_points;
                if (userRankEl) userRankEl.textContent = userEntry.rank;
            }
        }
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

async function loadPicksData() {
    if (!currentUser) {
        return;
    }
    
    const weekSelect = document.getElementById('week-select');
    const selectedWeek = weekSelect ? weekSelect.value : currentWeek;
    
    try {
        const response = await fetch(`/api/matches?week=${selectedWeek}`);
        const data = await response.json();
        
        if (response.ok) {
            displayMatches(data, selectedWeek);
        }
    } catch (error) {
        console.error('Error loading picks data:', error);
    }
}

function displayMatches(matches, week) {
    const container = document.getElementById('games-container');
    if (!container) return;
    
    if (matches.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><p>Keine Spiele für diese Woche gefunden</p></div>';
        return;
    }
    
    container.innerHTML = matches.map(match => `
        <div class="game-card" data-match-id="${match.id}">
            <div class="game-header">
                <div class="game-date">${formatDate(match.game_date)}</div>
                ${match.game_started ? '<div class="game-status">Spiel bereits gestartet</div>' : ''}
            </div>
            <div class="game-content">
                <div class="teams-container">
                    <div class="team ${match.away_team_available ? '' : 'disabled'}" data-team-id="${match.away_team_id}">
                        <img src="/static/logos/${match.away_team_name.toLowerCase().replace(/\s+/g, '_')}.png" 
                             alt="${match.away_team_name}" class="team-logo" 
                             onerror="this.src='/static/logos/default.png'">
                        <div class="team-name">${match.away_team_name}</div>
                        ${!match.away_team_available ? '<div class="team-status">Nicht verfügbar</div>' : ''}
                    </div>
                    <div class="vs-divider">@</div>
                    <div class="team ${match.home_team_available ? '' : 'disabled'}" data-team-id="${match.home_team_id}">
                        <img src="/static/logos/${match.home_team_name.toLowerCase().replace(/\s+/g, '_')}.png" 
                             alt="${match.home_team_name}" class="team-logo"
                             onerror="this.src='/static/logos/default.png'">
                        <div class="team-name">${match.home_team_name}</div>
                        ${!match.home_team_available ? '<div class="team-status">Nicht verfügbar</div>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
    
    // Add click handlers for team selection
    container.querySelectorAll('.team:not(.disabled)').forEach(team => {
        team.addEventListener('click', function() {
            const matchId = this.closest('.game-card').dataset.matchId;
            const teamId = this.dataset.teamId;
            selectTeam(matchId, teamId, week);
        });
    });
}

async function loadLeaderboardData() {
    const container = document.getElementById('leaderboard-content');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner"></i><p>Lade Rangliste...</p></div>';
    
    try {
        const response = await fetch('/api/leaderboard');
        const data = await response.json();
        
        if (response.ok) {
            container.innerHTML = data.map(entry => `
                <div class="leaderboard-row ${currentUser && entry.username === currentUser.username ? 'current-user' : ''}">
                    <div class="player-rank">${entry.rank}</div>
                    <div class="player-name">${entry.username}</div>
                    <div class="player-points">${entry.total_points}</div>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Fehler beim Laden der Rangliste</p></div>';
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Verbindungsfehler</p></div>';
    }
}

async function loadAllPicksData() {
    const container = document.getElementById('all-picks-content');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner"></i><p>Lade alle Picks...</p></div>';
    
    try {
        const response = await fetch('/api/all-picks');
        const data = await response.json();
        
        if (response.ok) {
            displayAllPicks(data);
        } else {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Fehler beim Laden der Picks</p></div>';
        }
    } catch (error) {
        console.error('Error loading all picks:', error);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Verbindungsfehler</p></div>';
    }
}

function displayAllPicks(picksData) {
    const container = document.getElementById('all-picks-content');
    if (!container) return;
    
    const hideCompleted = document.getElementById('hide-completed').checked;
    
    let html = '';
    
    Object.keys(picksData).forEach(week => {
        const weekData = picksData[week];
        
        // Skip current week if hide completed is checked
        if (hideCompleted && parseInt(week) === currentWeek) {
            return;
        }
        
        html += `
            <div class="week-section">
                <h3 class="week-title">Woche ${week}</h3>
                <table class="picks-table">
                    <thead>
                        <tr>
                            <th>Spieler</th>
                            <th>Pick</th>
                            <th>Ergebnis</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${weekData.map(pick => `
                            <tr>
                                <td>${pick.username}</td>
                                <td>
                                    <div class="pick-team">
                                        <img src="/static/logos/${pick.team_name.toLowerCase().replace(/\s+/g, '_')}.png" 
                                             alt="${pick.team_name}" class="pick-team-logo"
                                             onerror="this.src='/static/logos/default.png'">
                                        ${pick.team_name}
                                    </div>
                                </td>
                                <td>
                                    ${pick.points !== null ? 
                                        `<span class="pick-result ${pick.points > 0 ? 'correct' : 'incorrect'}">
                                            ${pick.points > 0 ? 'Richtig' : 'Falsch'}
                                        </span>` : 
                                        'Ausstehend'
                                    }
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    });
    
    if (html === '') {
        html = '<div class="empty-state"><i class="fas fa-inbox"></i><p>Keine Picks gefunden</p></div>';
    }
    
    container.innerHTML = html;
}

// Utility Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('de-DE', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    // Hide and remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

async function selectTeam(matchId, teamId, week) {
    if (!currentUser) {
        showToast('Bitte zuerst anmelden', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/picks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: currentUser.id,
                week: week,
                team_id: teamId,
                pick_type: 'winner'
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('Pick erfolgreich gespeichert!', 'success');
            loadPicksData(); // Reload picks
        } else {
            showToast(data.error || 'Fehler beim Speichern des Picks', 'error');
        }
    } catch (error) {
        console.error('Error selecting team:', error);
        showToast('Verbindungsfehler', 'error');
    }
}

// Week selector handler
document.addEventListener('DOMContentLoaded', function() {
    const weekSelect = document.getElementById('week-select');
    if (weekSelect) {
        weekSelect.addEventListener('change', function() {
            if (currentSection === 'picks') {
                loadPicksData();
            }
        });
    }
    
    // Hide completed picks filter
    const hideCompletedCheckbox = document.getElementById('hide-completed');
    if (hideCompletedCheckbox) {
        hideCompletedCheckbox.addEventListener('change', function() {
            if (currentSection === 'all-picks') {
                loadAllPicksData();
            }
        });
    }
});

