// API base URL
const API_BASE = '';

// Global variables
let currentUser = null;
let currentWeek = null; // Will be set dynamically from API

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const section = urlParams.get('section');
    const week = urlParams.get('week');

    initializeApp(section, week);

    const hideCurrentPicksToggle = document.getElementById('hide-current-picks');
    if (hideCurrentPicksToggle) {
        hideCurrentPicksToggle.addEventListener('change', function() {
            if (document.getElementById('all-picks-section').style.display !== 'none') {
                loadAllPicksData();
            }
        });
    }
});

// Initialize the app
async function initializeApp(section = null, week = null) {
    setupNavigation();
    setupModal();
    setupLoginForm();
    
    // Initialize pick modal
    initializePickModal();
    
    await checkAuthStatus();
    await getCurrentWeek();

    if (section) {
        showSection(section);
        if (section === 'picks' && week) {
            // Set the week parameter for picks section
            currentWeek = parseInt(week) || currentWeek;
            loadPicksData(week);
        }
    } else {
        loadDashboardData();
    }
}

// Set up navigation
function setupNavigation() {
    const dashboardLink = document.getElementById('dashboard-link');
    const picksLink = document.getElementById('picks-link');
    const leaderboardLink = document.getElementById('leaderboard-link');
    const allPicksLink = document.getElementById('all-picks-link');
    
    dashboardLink.addEventListener('click', function(e) {
        e.preventDefault();
        updateURL('dashboard');
        showSection('dashboard');
    });
    
    picksLink.addEventListener('click', function(e) {
        e.preventDefault();
        updateURL('picks', currentWeek);
        showSection('picks');
    });
    
    leaderboardLink.addEventListener('click', function(e) {
        e.preventDefault();
        updateURL('leaderboard');
        showSection('leaderboard');
    });
    
    allPicksLink.addEventListener('click', function(e) {
        e.preventDefault();
        updateURL('all-picks');
        showSection('all-picks');
    });
}

// Update URL parameters
function updateURL(section, week = null) {
    const url = new URL(window.location);
    url.searchParams.set('section', section);
    
    if (week && section === 'picks') {
        url.searchParams.set('week', week);
    } else {
        url.searchParams.delete('week');
    }
    
    window.history.pushState({}, '', url);
}

// Show a specific section
function showSection(section) {
    // Hide all sections
    document.getElementById('dashboard-section').style.display = 'none';
    document.getElementById('picks-section').style.display = 'none';
    document.getElementById('leaderboard-section').style.display = 'none';
    document.getElementById('all-picks-section').style.display = 'none';
    
    // Show selected section
    document.getElementById(`${section}-section`).style.display = 'block';
    
    // Update navigation active state
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`${section}-link`).classList.add('active');
    
    // Load data for the section
    switch (section) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'picks':
            loadPicksData();
            break;
        case 'leaderboard':
            loadLeaderboardData();
            break;
        case 'all-picks':
            loadAllPicksData();
            break;
    }
}

// Setup modal
function setupModal() {
    const modal = document.getElementById('login-modal');
    const closeBtn = document.querySelector('.close');
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Setup login form
function setupLoginForm() {
    const loginButton = document.getElementById('login-button');
    const loginForm = document.getElementById('login-form');
    
    loginButton.addEventListener('click', function() {
        document.getElementById('login-modal').style.display = 'block';
    });
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        login();
    });
}

// Login function
async function login() {
    const username = document.getElementById('username-input').value;
    const password = document.getElementById('password-input').value;
    
    if (!username || !password) {
        showToast('error', 'Bitte Benutzername und Passwort eingeben');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.user) {
            // Store user data
            currentUser = data.user;
            localStorage.setItem('user', JSON.stringify(currentUser));
            
            // Update UI
            updateAuthUI();
            
            // Clear form
            document.getElementById('username-input').value = '';
            document.getElementById('password-input').value = '';
            
            // Hide modal
            document.getElementById('login-modal').style.display = 'none';
            
            // Show success message
            showToast('success', 'Login erfolgreich');
            
            // Reload data
            loadDashboardData();
        } else {
            showToast('error', data.error || 'Login fehlgeschlagen');
        }
    } catch (error) {
        console.error('Error during login:', error);
        showToast('error', 'Ein Fehler ist aufgetreten');
    } finally {
        hideLoading();
    }
}

// Logout function
async function logout() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/auth/logout`, {
            method: 'POST'
        });
        
        if (response.ok) {
            // Clear user data
            currentUser = null;
            localStorage.removeItem('user');
            
            // Update UI
            updateAuthUI();
            
            // Show success message
            showToast('success', 'Logout erfolgreich');
            
            // Go back to dashboard
            showSection('dashboard');
        } else {
            showToast('error', 'Logout fehlgeschlagen');
        }
    } catch (error) {
        console.error('Error during logout:', error);
        showToast('error', 'Ein Fehler ist aufgetreten');
    } finally {
        hideLoading();
    }
}

// Check authentication status
async function checkAuthStatus() {
    try {
        // First check localStorage
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            try {
                currentUser = JSON.parse(storedUser);
                updateAuthUI();
                return;
            } catch (e) {
                console.error('Error parsing stored user:', e);
                localStorage.removeItem('user');
            }
        }
        
        // If no stored user or parsing failed, check with server
        const response = await fetch(`${API_BASE}/api/auth/me`);
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.user) {
                currentUser = data.user;
                localStorage.setItem('user', JSON.stringify(currentUser));
                updateAuthUI();
            }
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
    }
}

// Update authentication UI
function updateAuthUI() {
    const userDetails = document.getElementById('user-details');
    const loginButton = document.getElementById('login-button');
    const usernameElement = document.getElementById('username');
    const logoutButton = document.getElementById('logout-button');
    
    if (currentUser) {
        userDetails.style.display = 'flex';
        loginButton.style.display = 'none';
        usernameElement.textContent = currentUser.username;
        
        // Add logout event listener
        logoutButton.addEventListener('click', logout);
    } else {
        userDetails.style.display = 'none';
        loginButton.style.display = 'block';
    }
}

// Get current week - CORRECTED to properly determine current week
async function getCurrentWeek() {
    try {
        const response = await fetch(`${API_BASE}/api/current-week`);
        
        if (response.ok) {
            const data = await response.json();
            currentWeek = data.current_week;
            document.getElementById('current-week').textContent = currentWeek;
        } else {
            // Fallback to week 3 based on context requirements
            currentWeek = 3;
            document.getElementById('current-week').textContent = currentWeek;
        }
    } catch (error) {
        console.error('Error getting current week:', error);
        // Fallback to week 3 based on context requirements
        currentWeek = 3;
        document.getElementById('current-week').textContent = currentWeek;
    }
}

// Load dashboard data
async function loadDashboardData() {
    if (!currentUser) {
        document.getElementById('user-score').textContent = '0';
        document.getElementById('user-rank').textContent = '-';
        document.getElementById('opponent-scores').innerHTML = 'Bitte einloggen';
        document.getElementById('recent-picks').innerHTML = 'Bitte einloggen';
        document.getElementById('eliminated-teams').innerHTML = 'Bitte einloggen';
        return;
    }
    
    try {
        // Get user score
        const scoreResponse = await fetch(`${API_BASE}/api/picks/score?user_id=${currentUser.id}`);
        
        if (scoreResponse.ok) {
            const scoreData = await scoreResponse.json();
            
            // Update user score
            document.getElementById('user-score').textContent = scoreData.user.score;
            
            // Update opponent scores with correct heading
            let opponentHtml = '<h4>Punkte Gegner</h4>';
            
            if (scoreData.opponents.length > 0) {
                scoreData.opponents.forEach(opponent => {
                    opponentHtml += `
                        <div class="opponent-score">
                            <span class="opponent-name">${opponent.username}:</span>
                            <span class="opponent-points">${opponent.score} Punkte</span>
                        </div>
                    `;
                });
            } else {
                opponentHtml += 'Keine Gegenspieler gefunden';
            }
            
            document.getElementById('opponent-scores').innerHTML = opponentHtml;
        } else {
            document.getElementById('opponent-scores').innerHTML = 'Fehler beim Laden der Punkte';
        }
        
        // Get user rank with correct format
        const rankResponse = await fetch(`${API_BASE}/api/user/rank?user_id=${currentUser.id}`);
        
        if (rankResponse.ok) {
            const rankData = await rankResponse.json();
            document.getElementById('user-rank').textContent = `Du bist aktuell auf Platz ${rankData.rank}`;
        } else {
            document.getElementById('user-rank').textContent = '-';
        }
        
        // Get recent picks with small logos
        const picksResponse = await fetch(`${API_BASE}/api/picks/recent?user_id=${currentUser.id}`);
        
        if (picksResponse.ok) {
            const picksData = await picksResponse.json();
            
            if (picksData.picks && picksData.picks.length > 0) {
                let picksHtml = '<h4>Letzte Picks</h4>';
                
                picksData.picks.forEach(pick => {
                    let resultText = 'Ausstehend';
                    let resultClass = 'pending';
                    
                    if (pick.is_completed) {
                        if (pick.is_correct) {
                            resultText = 'Richtig';
                            resultClass = 'correct';
                        } else {
                            resultText = 'Falsch';
                            resultClass = 'incorrect';
                        }
                    }
                    
                    picksHtml += `
                        <div class="recent-pick">
                            <img src="${pick.team_logo}" alt="${pick.team}" class="team-logo-small">
                            <div class="recent-pick-info">
                                <div class="recent-pick-week">Woche ${pick.week}</div>
                                <div class="recent-pick-team">${pick.team}</div>
                            </div>
                            <div class="recent-pick-result ${resultClass}">${resultText}</div>
                        </div>
                    `;
                });
                
                document.getElementById('recent-picks').innerHTML = picksHtml;
            } else {
                document.getElementById('recent-picks').innerHTML = '<h4>Letzte Picks</h4>Noch keine Picks gemacht';
            }
        } else {
            document.getElementById('recent-picks').innerHTML = 'Fehler beim Laden der Picks';
        }
        
        // Get eliminated teams with correct heading
        const eliminatedResponse = await fetch(`${API_BASE}/api/picks/eliminated?user_id=${currentUser.id}`);
        
        if (eliminatedResponse.ok) {
            const eliminatedData = await eliminatedResponse.json();
            
            let eliminatedHtml = '<h4>Eliminierte Teams</h4>';
            
            if (eliminatedData.eliminated_teams && eliminatedData.eliminated_teams.length > 0) {
                eliminatedData.eliminated_teams.forEach(team => {
                    eliminatedHtml += `
                        <div class="eliminated-team">
                            <img src="${team.logo_url}" alt="${team.name}" class="eliminated-team-logo team-logo-small">
                            <div class="eliminated-team-name">${team.name}</div>
                        </div>
                    `;
                });
            } else {
                eliminatedHtml += 'Keine eliminierten Teams';
            }
            
            document.getElementById('eliminated-teams').innerHTML = eliminatedHtml;
        } else {
            document.getElementById('eliminated-teams').innerHTML = 'Fehler beim Laden der eliminierten Teams';
        }
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        document.getElementById('opponent-scores').innerHTML = 'Fehler beim Laden der Punkte';
        document.getElementById('recent-picks').innerHTML = 'Fehler beim Laden der Picks';
        document.getElementById('eliminated-teams').innerHTML = 'Fehler beim Laden der eliminierten Teams';
    }
}

// Load picks data
async function loadPicksData(week = null) {
    if (!currentUser) {
        showToast('warning', 'Bitte logge dich ein, um deine Picks zu sehen');
        return;
    }
    
    try {
        showLoading();
        
        // If no week specified, use current week
        if (!week) {
            week = currentWeek;
        }
        
        // Load weeks for selector
        const weeksResponse = await fetch(`${API_BASE}/api/matches`);
        
        if (weeksResponse.ok) {
            const weeksData = await weeksResponse.json();
            
            // Get unique weeks
            const weeks = [...new Set(weeksData.matches.map(match => match.week))].sort((a, b) => a - b);
            
            // Populate week selector
            const weekSelect = document.getElementById('week-select');
            weekSelect.innerHTML = '';
            
            weeks.forEach(w => {
                const option = document.createElement('option');
                option.value = w;
                option.textContent = `Woche ${w}`;
                option.selected = w === parseInt(week);
                weekSelect.appendChild(option);
            });
            
            // Add event listener to week selector with URL update
            weekSelect.addEventListener('change', () => {
                const selectedWeek = weekSelect.value;
                
                // Update URL parameters
                const url = new URL(window.location);
                url.searchParams.set('section', 'picks');
                url.searchParams.set('week', selectedWeek);
                window.history.pushState({}, '', url);
                
                // Load matches for selected week
                loadMatchesForWeek(selectedWeek);
            });
            
            // Load matches for selected week
            loadMatchesForWeek(week);
        } else {
            document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Wochen';
        }
    } catch (error) {
        console.error('Error loading picks data:', error);
        document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Picks';
    } finally {
        hideLoading();
    }
}

// CORRECTED: Load matches for a specific week with proper team availability logic
async function loadMatchesForWeek(week) {
    try {
        showLoading();
        
        // Get matches for the week
        const matchesResponse = await fetch(`${API_BASE}/api/matches?week=${week}`);
        
        if (!matchesResponse.ok) {
            document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Matches';
            hideLoading();
            return;
        }
        
        const matchesData = await matchesResponse.json();
        
        // Get user's picks for the week
        const picksResponse = await fetch(`${API_BASE}/api/picks?user_id=${currentUser.id}&week=${week}`);
        
        if (!picksResponse.ok) {
            document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Picks';
            hideLoading();
            return;
        }
        
        const picksData = await picksResponse.json();
        
        // Check if user already has a pick for this week (only one pick per week allowed)
        const hasWeekPick = picksData.picks.length > 0;
        const weekPickMatch = hasWeekPick ? picksData.picks[0].match : null;
        
        // Get eliminated teams with type information
        const eliminatedResponse = await fetch(`${API_BASE}/api/picks/eliminated?user_id=${currentUser.id}`);
        
        if (!eliminatedResponse.ok) {
            document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der eliminierten Teams';
            hideLoading();
            return;
        }
        
        const eliminatedData = await eliminatedResponse.json();
        
        // CORRECTED: Properly separate eliminated teams by type
        const loserEliminatedTeamIds = eliminatedData.eliminated_teams
            .filter(team => team.elimination_type === 'loser')
            .map(team => team.id);
        
        // Get team winner usage
        const teamUsageResponse = await fetch(`${API_BASE}/api/picks/team-usage?user_id=${currentUser.id}`);
        
        if (!teamUsageResponse.ok) {
            document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Team-Nutzung';
            hideLoading();
            return;
        }
        
        const teamUsageData = await teamUsageResponse.json();
        const teamUsageMap = {};
        teamUsageData.team_usage.forEach(usage => {
            teamUsageMap[usage.team.id] = usage;
        });
        
        // Create HTML for matches
        let matchesHtml = '';
        
        if (matchesData.matches.length === 0) {
            matchesHtml = '<p>Keine Matches für diese Woche gefunden</p>';
        } else {
            // Show simplified rules and info
            if (hasWeekPick) {
                matchesHtml += `
                    <div class="week-pick-info">
                        <h3>Dein Pick für Woche ${week}</h3>
                        <p>Du kannst deinen Pick zwischen allen noch nicht gestarteten Spielen wechseln.</p>
                    </div>
                `;
            } else {
                matchesHtml += `
                    <div class="week-pick-info">
                        <h3>Wähle EINEN Pick für Woche ${week}</h3>
                        <p>Du kannst deinen Pick zwischen allen noch nicht gestarteten Spielen wechseln.</p>
                    </div>
                `;
            }
            
            // Add clear rule descriptions
            matchesHtml += `
                <div class="pick-rules-simplified">
                    <h4>Regeln:</h4>
                    <div class="rule-item">
                        <i class="fas fa-times-circle rule-icon"></i>
                        <span>Teams die bereits als Verlierer gewählt wurden, können nicht noch einmal als Verlierer gewählt werden</span>
                    </div>
                    <div class="rule-item">
                        <i class="fas fa-trophy rule-icon"></i>
                        <span>Teams die bereits 2x als Gewinner gewählt wurden, können nicht noch einmal als Gewinner gewählt werden</span>
                    </div>
                    <div class="rule-item">
                        <i class="fas fa-eye-slash rule-icon"></i>
                        <span>Nicht verfügbare Teams werden ausgegraut dargestellt</span>
                    </div>
                </div>
            `;
            
            matchesData.matches.forEach(match => {
                // Check if user has a pick for this match
                const userPick = picksData.picks.find(pick => pick.match.id === match.id);
                const selectedTeamId = userPick ? userPick.chosen_team.id : null;
                
                // Check if game has started (Backend provides this info)
                const isGameStarted = match.is_game_started;
                
                // Format date and time in Vienna timezone
                const matchDate = new Date(match.start_time_vienna);
                const dateOptions = { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    timeZone: 'Europe/Vienna'
                };
                
                const formattedDate = matchDate.toLocaleDateString('de-DE', dateOptions);
                
                // Get team usage status
                const awayTeamUsage = teamUsageMap[match.away_team.id];
                const homeTeamUsage = teamUsageMap[match.home_team.id];
                
                // CORRECTED: Team availability logic - Dallas Cowboys should be available for Manuel in week 3
                // A team is available if:
                // 1. Game hasn't started
                // 2. Team hasn't been picked as loser before (permanently eliminated)
                // 3. Team hasn't been picked as winner 2 times already
                const isAwayTeamAvailable = !isGameStarted && 
                    !loserEliminatedTeamIds.includes(match.away_team.id) && 
                    !(awayTeamUsage && awayTeamUsage.usage_count >= 2);
                
                const isHomeTeamAvailable = !isGameStarted && 
                    !loserEliminatedTeamIds.includes(match.home_team.id) && 
                    !(homeTeamUsage && homeTeamUsage.usage_count >= 2);
                
                // Determine CSS classes for graying out unavailable teams
                const awayTeamClass = isAwayTeamAvailable ? '' : 'team-unavailable';
                const homeTeamClass = isHomeTeamAvailable ? '' : 'team-unavailable';
                const matchButtonClass = (isAwayTeamAvailable || isHomeTeamAvailable) ? '' : 'match-disabled';
                
                matchesHtml += `
                    <div class="match-card ${matchButtonClass} ${isGameStarted ? 'game-started' : ''}" data-match-id="${match.id}">
                        <div class="match-header">
                            <div class="match-date">${formattedDate}</div>
                            ${isGameStarted ? '<div class="game-started-info">Spiel bereits gestartet</div>' : ''}
                        </div>
                        <div class="match-button ${isGameStarted ? 'disabled' : ''}" 
                             data-match-id="${match.id}"
                             data-away-team-id="${match.away_team.id}"
                             data-home-team-id="${match.home_team.id}"
                             data-away-team-name="${match.away_team.name}"
                             data-home-team-name="${match.home_team.name}"
                             data-away-team-logo="${match.away_team.logo_url}"
                             data-home-team-logo="${match.home_team.logo_url}">
                            <div class="match-teams-display">
                                <div class="team-display ${selectedTeamId === match.away_team.id ? 'selected' : ''} ${awayTeamClass}">
                                    <img src="${match.away_team.logo_url}" alt="${match.away_team.name}" class="team-logo-large">
                                    <div class="team-name">${match.away_team.name}</div>
                                    ${selectedTeamId === match.away_team.id ? '<div class="pick-indicator"><i class="fas fa-check"></i></div>' : ''}
                                    ${match.is_completed && match.winner_team && match.winner_team.id === match.away_team.id ? '<div class="winner-indicator"><i class="fas fa-trophy"></i></div>' : ''}
                                    ${!isAwayTeamAvailable ? '<div class="unavailable-overlay">Nicht verfügbar</div>' : ''}
                                </div>
                                
                                <div class="match-vs">@</div>
                                
                                <div class="team-display ${selectedTeamId === match.home_team.id ? 'selected' : ''} ${homeTeamClass}">
                                    <img src="${match.home_team.logo_url}" alt="${match.home_team.name}" class="team-logo-large">
                                    <div class="team-name">${match.home_team.name}</div>
                                    ${selectedTeamId === match.home_team.id ? '<div class="pick-indicator"><i class="fas fa-check"></i></div>' : ''}
                                    ${match.is_completed && match.winner_team && match.winner_team.id === match.home_team.id ? '<div class="winner-indicator"><i class="fas fa-trophy"></i></div>' : ''}
                                    ${!isHomeTeamAvailable ? '<div class="unavailable-overlay">Nicht verfügbar</div>' : ''}
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
        }
        
        document.getElementById('matches-container').innerHTML = matchesHtml;
        
        // Use event delegation for match buttons
        setupMatchButtonEventDelegation();

    } catch (error) {
        console.error('Error loading matches for week:', error);
        document.getElementById('matches-container').innerHTML = 'Fehler beim Laden der Matches';
    } finally {
        hideLoading();
    }
}

// Setup event delegation for match buttons
function setupMatchButtonEventDelegation() {
    const matchesContainer = document.getElementById('matches-container');
    
    // Remove any existing event listeners
    matchesContainer.removeEventListener('click', handleMatchButtonClick);
    
    // Add event delegation
    matchesContainer.addEventListener('click', handleMatchButtonClick);
}

// Handle match button clicks with event delegation
function handleMatchButtonClick(event) {
    // Find the closest match button
    const matchButton = event.target.closest('.match-button');
    
    if (!matchButton || matchButton.classList.contains('disabled')) {
        return;
    }
    
    // Get match data
    const matchId = matchButton.dataset.matchId;
    const awayTeamId = matchButton.dataset.awayTeamId;
    const homeTeamId = matchButton.dataset.homeTeamId;
    const awayTeamName = matchButton.dataset.awayTeamName;
    const homeTeamName = matchButton.dataset.homeTeamName;
    const awayTeamLogo = matchButton.dataset.awayTeamLogo;
    const homeTeamLogo = matchButton.dataset.homeTeamLogo;
    
    // Show pick modal
    showPickModal({
        matchId: matchId,
        awayTeam: {
            id: awayTeamId,
            name: awayTeamName,
            logo: awayTeamLogo
        },
        homeTeam: {
            id: homeTeamId,
            name: homeTeamName,
            logo: homeTeamLogo
        }
    });
}

// Initialize pick modal
function initializePickModal() {
    const modal = document.getElementById('pick-modal');
    const closeBtn = modal.querySelector('.close');
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Show pick modal
function showPickModal(matchData) {
    const modal = document.getElementById('pick-modal');
    const modalContent = modal.querySelector('.modal-content');
    
    modalContent.innerHTML = `
        <span class="close">&times;</span>
        <h2>Pick für Match wählen</h2>
        <div class="modal-match-display">
            <div class="modal-team" data-team-id="${matchData.awayTeam.id}">
                <img src="${matchData.awayTeam.logo}" alt="${matchData.awayTeam.name}" class="modal-team-logo">
                <div class="modal-team-name">${matchData.awayTeam.name}</div>
                <button class="modal-pick-btn" data-team-id="${matchData.awayTeam.id}" data-team-name="${matchData.awayTeam.name}">
                    Als Gewinner wählen
                </button>
            </div>
            
            <div class="modal-vs">@</div>
            
            <div class="modal-team" data-team-id="${matchData.homeTeam.id}">
                <img src="${matchData.homeTeam.logo}" alt="${matchData.homeTeam.name}" class="modal-team-logo">
                <div class="modal-team-name">${matchData.homeTeam.name}</div>
                <button class="modal-pick-btn" data-team-id="${matchData.homeTeam.id}" data-team-name="${matchData.homeTeam.name}">
                    Als Gewinner wählen
                </button>
            </div>
        </div>
    `;
    
    // Add event listeners to pick buttons
    const pickButtons = modalContent.querySelectorAll('.modal-pick-btn');
    pickButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const teamId = this.dataset.teamId;
            const teamName = this.dataset.teamName;
            
            // Make the pick
            makePick(matchData.matchId, teamId, teamName);
            
            // Close modal
            modal.style.display = 'none';
        });
    });
    
    // Re-add close event listener
    const closeBtn = modalContent.querySelector('.close');
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    modal.style.display = 'block';
}

// Make a pick
async function makePick(matchId, teamId, teamName) {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/picks`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: currentUser.id,
                match_id: matchId,
                chosen_team_id: teamId
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('success', `Pick für ${teamName} erfolgreich gespeichert`);
            
            // Reload the current week's matches
            const urlParams = new URLSearchParams(window.location.search);
            const currentWeekParam = urlParams.get('week') || currentWeek;
            loadMatchesForWeek(currentWeekParam);
        } else {
            showToast('error', data.error || 'Fehler beim Speichern des Picks');
        }
    } catch (error) {
        console.error('Error making pick:', error);
        showToast('error', 'Ein Fehler ist aufgetreten');
    } finally {
        hideLoading();
    }
}

// Load leaderboard data
async function loadLeaderboardData() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/leaderboard`);
        
        if (response.ok) {
            const data = await response.json();
            
            let leaderboardHtml = '';
            
            if (data.leaderboard && data.leaderboard.length > 0) {
                data.leaderboard.forEach((user, index) => {
                    const emoji = user.emoji || '';
                    leaderboardHtml += `
                        <div class="leaderboard-entry">
                            <div class="leaderboard-rank">${user.rank}${emoji}</div>
                            <div class="leaderboard-username">${user.username}</div>
                            <div class="leaderboard-score">${user.score} Punkte</div>
                        </div>
                    `;
                });
            } else {
                leaderboardHtml = '<p>Keine Leaderboard-Daten verfügbar</p>';
            }
            
            document.getElementById('leaderboard-container').innerHTML = leaderboardHtml;
        } else {
            document.getElementById('leaderboard-container').innerHTML = 'Fehler beim Laden des Leaderboards';
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
        document.getElementById('leaderboard-container').innerHTML = 'Fehler beim Laden des Leaderboards';
    } finally {
        hideLoading();
    }
}

// Load all picks data
async function loadAllPicksData() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/picks`);
        
        if (response.ok) {
            const data = await response.json();
            
            let allPicksHtml = '';
            
            if (data.picks && data.picks.length > 0) {
                // Group picks by week
                const picksByWeek = {};
                data.picks.forEach(pick => {
                    if (!picksByWeek[pick.week]) {
                        picksByWeek[pick.week] = [];
                    }
                    picksByWeek[pick.week].push(pick);
                });
                
                // Sort weeks
                const sortedWeeks = Object.keys(picksByWeek).sort((a, b) => parseInt(b) - parseInt(a));
                
                sortedWeeks.forEach(week => {
                    allPicksHtml += `<h3>Woche ${week}</h3>`;
                    
                    picksByWeek[week].forEach(pick => {
                        let resultText = 'Ausstehend';
                        let resultClass = 'pending';
                        
                        if (pick.is_completed) {
                            if (pick.is_correct) {
                                resultText = 'Richtig';
                                resultClass = 'correct';
                            } else {
                                resultText = 'Falsch';
                                resultClass = 'incorrect';
                            }
                        }
                        
                        allPicksHtml += `
                            <div class="all-picks-entry">
                                <div class="all-picks-user">${pick.user}</div>
                                <div class="all-picks-team">
                                    <img src="${pick.team_logo}" alt="${pick.team}" class="team-logo-small">
                                    ${pick.team}
                                </div>
                                <div class="all-picks-result ${resultClass}">${resultText}</div>
                            </div>
                        `;
                    });
                });
            } else {
                allPicksHtml = '<p>Keine Picks verfügbar</p>';
            }
            
            document.getElementById('all-picks-container').innerHTML = allPicksHtml;
        } else {
            document.getElementById('all-picks-container').innerHTML = 'Fehler beim Laden aller Picks';
        }
    } catch (error) {
        console.error('Error loading all picks:', error);
        document.getElementById('all-picks-container').innerHTML = 'Fehler beim Laden aller Picks';
    } finally {
        hideLoading();
    }
}

// Utility functions
function showLoading() {
    // Show loading indicator
    const loadingElement = document.getElementById('loading');
    if (loadingElement) {
        loadingElement.style.display = 'block';
    }
}

function hideLoading() {
    // Hide loading indicator
    const loadingElement = document.getElementById('loading');
    if (loadingElement) {
        loadingElement.style.display = 'none';
    }
}

function showToast(type, message) {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    // Add to page
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    // Hide and remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

